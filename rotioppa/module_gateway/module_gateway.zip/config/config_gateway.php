<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['modulename'] = 'gateway';
$config['page_home'] = 'gateway';
