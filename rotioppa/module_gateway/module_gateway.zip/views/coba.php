<html>
<head></head>
<body>
<a href="<?=site_url(config_item('modulename').'/banner')?>" class="orange">test</a>
</body>
</html>