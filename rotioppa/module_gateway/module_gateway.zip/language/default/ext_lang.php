<?php
$lang['no_data_produk']='No data available!';
