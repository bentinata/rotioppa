<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test extends Controller 
{

    function Test()
    {
        parent::Controller();
    }
    
    function index()
    {
		echo "haloo";
   }

} 
