<? if (!defined('BASEPATH')) exit('No direct script access allowed');
class Home extends Aff_Controller{
	function __construct(){
		parent::__construct();
		/* load lang */
		$this->lang->load('aff');
		/* load model */
		$this->load->model('aff_model', 'am');
	}
	function index(){
		$this->template
		->set_partial('pg_login','form_login');
		
        $data=false;
		$this->template->set_view ('home',$data,config_item('modulename'));
		#redirect('home/comming');
	}
    function samplecrypt(){
        $msg = 'My';

        $this->load->library('encrypt');
        $key = 'password';
        $encrypted_string = $this->encrypt->encode($msg, $key);

        echo $encrypted_string;
        $plaintext_string = $this->encrypt->decode($en, $key);
        echo '**'.$plaintext_string.'<br><br>';

        $this->load->helper('cookie');
        #set_cookie($name, $value, $expire, $domain, $path, $prefix);
        get_cookie('some_cookie');
        #delete_cookie("name");

    }
    function forgetpass(){
        $this->template->clear_layout();
        if($this->input->post('send_mail')){
			$this->load->library('captcha_lib');
			if($this->captcha_lib->validate_code($this->input->post('captcha'))){
                $this->load->helper('email');
                $to = $this->input->post('email');
				if(valid_email($to)){
					// get aff_detail
					$det_aff = $this->am->detail_aff_bymail($to);
					if($det_aff){
						// send mail
						$this->load->library('mail_lib');
						if($this->mail_lib->sendpassaff($to,$det_aff->password,$det_aff->nama_panggilan)){
							$echo = array('res'=>'1','msg'=>lang('mail_success'));
						}else{
							$echo = array('res'=>'2','msg'=>lang('mail_error'));
						}
					}else{
						$echo = array('res'=>'2','msg'=>lang('mail_not_aff'));
					}
				}else{
					$echo = array('res'=>'2','msg'=>lang('mail_not_valid'));
                }

            }else{
				$echo = array('res'=>'2','msg'=>lang('captcha_error'));
			}
            echo json_encode($echo);
        }else{
            $data=false;
            $this->template->set_view ('forget_pass',$data,config_item('modulename'));
        }
    }

}
