<? if (!defined('BASEPATH')) exit('No direct script access allowed');
class Aff extends Aff_Controller{
    var $affid;
	function __construct(){
		parent::__construct();
		/* load lang */
		$this->lang->load('aff');
		/* load model */
		$this->load->model('aff_model', 'am');
        $this->load->model('lap_model', 'lm');
		$this->load->model('global_model', 'gm');
		
        $this->affid =$this->login_lib->a_get_data('id');

	}
	function index(){
		// current komisi
		#$data['this_month'] = date('Y-n', mktime(0,0,0,date('n')-1, 1, date('Y'))); // tampilkan bulan sebelumnya saja
		$search['aff'] = $this->affid;
		$data['komisi_anda']=$this->lm->komisi_anda($this->affid); 
		#$search['range'] = array('first'=>$data['this_month'],'last'=>$data['this_month']);
		#$data['this_komisi'] = $this->lm->list_komisi($search);

        $data['aff'] = $this->am->detail_aff($this->affid); #print_r($data['aff']); break;
        $data['info'] = $this->am->get_info();
        $data['faq'] = $this->am->get_faq();
        $search['type']='1'; // type utk pencarian berdasarkan tanggal
        $search['range']['first']=date('Y-m-d',strtotime("-7 day"));
        $search['range']['last']=date('Y-m-d');
        $data['startnumber']=0;
        $data['date1'] =$search['range']['first'];
        $data['date2'] =$search['range']['last'];
        $data['list_iklan'] = $this->lm->list_iklan($search);
        $data['list_produk'] = $this->lm->list_produk($search);
        $this->template->set_view ('aff',$data,config_item('modulename'));
    }
	function profile(){
	    if($this->input->post('_SAVE')){
			$pass=$this->input->post('password');
            $pass2=$this->input->post('password2');
            if($pass==$pass2){
    			$full=$this->input->post('fullname');
    			$nick=$this->input->post('nickname');
        		$tlp=$this->input->post('tlp');
                $hp=$this->input->post('hp');
        		$jenkel=$this->input->post('jenkel');
            	$lahir=$this->input->post('thn').'-'.$this->input->post('bln').'-'.$this->input->post('tgl');
            	$alamat=$this->input->post('alamat');
                $kota=$this->input->post('kota');
            	$prov=$this->input->post('prov');
            	$negara=$this->input->post('negara');
                $pay=$this->input->post('paymethod');
                $kom=$this->input->post('minkom');

                $this->am->update_aff($this->affid,$pass,$full,$nick,$tlp,$hp,$jenkel,$lahir,$alamat,$kota,$prov,$negara,$pay,$kom);#echo $this->am->db->last_query();
                $data['ok'] = true;$data['msg'] = lang('update_success');
            }else{
                $data['ok'] = false;$data['msg'] = lang('password_not_same');
            }
        }
        $data['aff'] = $this->am->detail_aff($this->affid);
		$this->template->set_view('profile',$data,config_item('modulename'));
	}
    function sendtomail(){
        // send mail
        $this->load->library('mail_lib');
        $to = $this->login_lib->a_get_data('email');
        $pass = $this->login_lib->a_get_data('password');
        $nick = $this->login_lib->a_get_data('nama_panggilan');
        if($this->mail_lib->sendpassaff($to,$pass,$nick)){
            java_alert(lang('send_mail_ok'));
        }else java_alert(lang('send_mail_er'));
		redirect_java(config_item('modulename').'/'.$this->router->class);
    }
    function get_subkat_byidkat(){
		$this->template->clear_layout();
		$idkat=$this->input->post('idkat');
		if(!$idkat)exit();
		$echo='';
		$sub = $this->gm->option_subkat($idkat);
		if($sub){foreach($sub as $idsub=>$dsub){
			$echo.='<option value="'.$idsub.'">'.$dsub.'</option>';
		}}
		echo $echo;
	}
	function faq(){
		$data=false;
		$this->template->set_view ('faq',$data,config_item('modulename'));
	}
}
