<? if (!defined('BASEPATH')) exit('No direct script access allowed');
class Review extends Aff_Controller{
    var $affid;
	function __construct(){
		parent::__construct();
		// check if has login
		$this->login_lib->a_check_not_login();
		/* load lang */
		$this->lang->load('aff',$this->globals->lang);
		/* load model */
		$this->load->module_model(config_item('modulename'), 'lap_model', 'rm');

		/* header description */
		$data['title'] 			= config_item('site_title');
		$data['keyword'] 		= config_item('site_keyword');
		$data['description'] 	= config_item('site_desc');
		$this->template->set_params($data);
	    #$this->template->set_layout();
        $this->affid =$this->login_lib->a_get_data('id');

		/* to check system speed and query --> just for admin */
		#$this->output->enable_profiler(TRUE);
	}
	function index(){
        #$data['list_track']=$this->rm->list_track($this->affid);
        #$this->template->set_view ('laporan',$data,config_item('modulename'));
        $this->lapiklan();
    }
    function lapiklan($ajax=false){
		$search['aff'] = $this->affid;
        if($ajax){
            $this->template->clear_layout();
            
    		$type = $this->input->post('tl');
			$data['forajax'] = "&tl=$type";
            $track = $this->input->post('track'); 
            if(!empty($track)){
				$search['track'] = explode('-',$track);
				$data['forajax'] .= "&track=$track";
			}

    		if($type=='1'){
                $tdate = $this->input->post('dt');
                $data['forajax'] .= "&dt=$tdate";
                $search['type'] = $tdate;
                if($tdate=='1'){
                    $search['range'] = get_week_range();
                }
            }else{
                $search['type'] = '1';
                $search['range']['first'] = $this->input->post('dt1');
                $search['range']['last'] = $this->input->post('dt2');
                $data['forajax'] .= '&dt1='.$search['range']['first'].'&dt2='.$search['range']['last'];
            }#print_r($search);
        }else{
            // tampilkan data bulan berjalan
            $search['type'] = '1';
            $search['range']['first'] = date('Y-m-01');
            $search['range']['last'] = date('Y-m-t');
            $data['forajax'] = '&tl=2&dt1='.$search['range']['first'].'&dt2='.$search['range']['last'];
        }

		// paging
		$this->load->helper('pagenav');
		$pg 				= GetPageNLimitVar(false,20); #print_r($pg);
		$paging['curpage'] 	= $this->input->post('start')!=''?$this->input->post('start'):$pg['curpage'];
		$paging['limit'] 	= $pg['limit'];
		$paging['total'] 	= $this->rm->list_iklan($search,false,false,true);
		$obj				= CreatePageNav($paging);
		$limitstart 		= GetLimitStart($paging['curpage'],$paging['limit']); #echo $limitstart;break;
		$data['paging'] 	= $obj;
		$data['thislink'] 	= false;#config_item('modulename').'/'.$this->router->class.'/'.$this->router->method;
		$data['limit'] 		= $paging['limit'];
		$data['startnumber']= $limitstart;
        $data['list_iklan']=$this->rm->list_iklan($search,$limitstart,$paging['limit'],false);#print_r($data['list_iklan']);

        if($ajax){
            if($ajax=='1')
                $this->template->set_view ('laporan_iklan2',$data,config_item('modulename'));
            else
                $this->template->set_view ('laporan_iklan',$data,config_item('modulename'));
        }else{
            $data['list_track']=$this->rm->list_track($this->affid);
            $this->template->set_view ('laporan',$data,config_item('modulename'));
        }
    }
    function lapproduk($ajax=false){
		$search['aff'] = $this->affid;
        if($ajax){
            $this->template->clear_layout();

    		$type = $this->input->post('tl');
    		$data['forajax'] = "&tl=$type";
            $track = $this->input->post('track'); 
            if(!empty($track)){ 
                $search['track'] = explode('-',$track);
                $data['forajax'] .= "&track=$track";
            }

    		if($type=='1'){
                $tdate = $this->input->post('dt');
                $data['forajax'] .= "&dt=$tdate";
                $search['type'] = $tdate;
                if($tdate=='1'){
                    $search['range'] = get_week_range();
                }
            }else{
                $search['type'] = '1';
                $search['range']['first'] = $this->input->post('dt1');
                $search['range']['last'] = $this->input->post('dt2');
                $data['forajax'] .= '&dt1='.$search['range']['first'].'&dt2='.$search['range']['last'];
            }#print_r($search);
        }else{
            // tampilkan data bulan berjalan
            $search['type'] = '1';
            $search['range']['first'] = date('Y-m-01');
            $search['range']['last'] = date('Y-m-t');
            $data['forajax'] = '&tl=2&dt1='.$search['range']['first'].'&dt2='.$search['range']['last'];
        }

    		// paging
    		$this->load->helper('pagenav');
    		$pg 				= GetPageNLimitVar(false,20); #print_r($pg);
    		$paging['curpage'] 	= $this->input->post('start')!=''?$this->input->post('start'):$pg['curpage'];
    		$paging['limit'] 	= $pg['limit'];
    		$paging['total'] 	= $this->rm->list_produk($search,false,false,true); #echo $paging['total'];
    		$obj				= CreatePageNav($paging);
    		$limitstart 		= GetLimitStart($paging['curpage'],$paging['limit']); #echo $limitstart;break;
    		$data['paging'] 	= $obj;
    		$data['thislink'] 	= false;#config_item('modulename').'/'.$this->router->class.'/'.$this->router->method;
    		$data['limit'] 		= $paging['limit'];
    		$data['startnumber']= $limitstart;
            $data['list_produk']=$this->rm->list_produk($search,$limitstart,$paging['limit'],false);#print_r($data['list_iklan']);


        if($ajax){
            if($ajax=='1')
                $this->template->set_view ('laporan_produk2',$data,config_item('modulename'));
            else
                $this->template->set_view ('laporan_produk3',$data,config_item('modulename'));
        }else{
            $data['list_track']=$this->rm->list_track($this->affid);
            $this->template->set_view ('laporan_produk',$data,config_item('modulename'));
        }
    }
    function lapkom($ajax=false){
        $search['aff'] = $this->affid;
        $search['range']['first'] = $this->input->post('dt1')?$this->input->post('dt1'):date('Y-01');
        $search['range']['last'] = $this->input->post('dt2')?$this->input->post('dt2'):date('Y-12');
        $data['forajax'] = '&dt1='.$search['range']['first'].'&dt2='.$search['range']['last'];

		// paging
		$this->load->helper('pagenav');
		$pg 				= GetPageNLimitVar(false,20); #print_r($pg);
		$paging['curpage'] 	= $this->input->post('start')!=''?$this->input->post('start'):$pg['curpage'];
		$paging['limit'] 	= $pg['limit'];
		$paging['total'] 	= $this->rm->list_komisi($search,false,false,true);
		$obj				= CreatePageNav($paging);
		$limitstart 		= GetLimitStart($paging['curpage'],$paging['limit']); #echo $limitstart;break;
		$data['paging'] 	= $obj;
		$data['thislink'] 	= false;#config_item('modulename').'/'.$this->router->class.'/'.$this->router->method;
		$data['limit'] 		= $paging['limit'];
		$data['startnumber']= $limitstart;
        $data['list_iklan']=$this->rm->list_komisi($search,$limitstart,$paging['limit'],false);#print_r($data['list_iklan']);


        if($ajax){
            $this->template->clear_layout();
            if($ajax=='1')
                $this->template->set_view ('laporan_komisi2',$data,config_item('modulename'));
            else
                $this->template->set_view ('laporan_komisi3',$data,config_item('modulename'));
        }else{
			$data['komisi_anda']=$this->rm->komisi_anda($this->affid); 
            $this->template->set_view ('laporan_komisi',$data,config_item('modulename'));
        }
    }
}
