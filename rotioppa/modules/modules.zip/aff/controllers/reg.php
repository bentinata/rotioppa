<? if (!defined('BASEPATH')) exit('No direct script access allowed');
class Reg extends Aff_Controller{
	function __construct(){
		parent::__construct();
		/* load lang */
		$this->lang->load('aff');
		/* load model */
		$this->load->model('aff_model', 'am');
	}
	function index(){
        $data = false;
		if($this->input->post('_REG')){
			$this->load->library('captcha_lib');
			if($this->captcha_lib->validate_code($this->input->post('captcha'))){
				$email=$this->input->post('email');
                $this->load->helper('email');
                if(valid_email($email)){
                    $this->load->model('login/login_model', 'lm');
                   	$data_user = $this->lm->check_aff($email);
			        if(!$data_user){
                        $pass=$this->input->post('password');
                        $pass2=$this->input->post('password2');
                        if($pass==$pass2){
            				$full=$this->input->post('fullname');
            				$nick=$this->input->post('nickname');
            				$tlp=$this->input->post('tlp');
                            $hp=$this->input->post('hp');
                    		$jenkel=$this->input->post('jenkel');
                        	$lahir=$this->input->post('thn').'-'.$this->input->post('bln').'-'.$this->input->post('tgl');
                        	$alamat=$this->input->post('alamat');
                            $kota=$this->input->post('kota');
                        	$prov=$this->input->post('prov');
                        	$negara=$this->input->post('negara');
                            $pay=$this->input->post('paymethod');
                            $kom=$this->input->post('minkom');
                            $web=$this->input->post('urlweb');
                            $code=get_rand(5,3).time();
            				$this->am->reg_aff($email,$pass,$full,$nick,$tlp,$hp,$jenkel,$lahir,$alamat,$kota,$prov,$negara,$pay,$kom,$code,$web,'1');

            				// send mail
            				$this->load->library('mail_lib');
                            $ln = site_url(ci()->module.'/reg/activation/'.$code.'/'.myEncrypt($email));
                            $this->mail_lib->reg_aff($email,$ln,$nick);

                            redirect('aff/reg/ok');
                        }else{
                            $data['ok'] = false;$data['msg'] = lang('password_not_same');
                        }
                    }else{
        				$data['ok'] = false;$data['msg'] = lang('email_has_list');
        			}
                }else{
    				$data['ok'] = false;$data['msg'] = lang('mail_not_valid');
    			}
            }else{
				$data['ok'] = false;$data['msg'] = lang('captcha_error');
			}
		}
		$this->template->set_view ('reg',$data,config_item('modulename'));
	}
    function ok(){
        $this->template->set_view ('reg_ok',false,config_item('modulename'));
    }
	function activation($code,$email){
		$email=myDecrypt($email); 
		$this->am->active_aff($code,$email);
		$detail = $this->am->detail_aff_bymail($email);
		$link_login = site_url('aff/home');

		// send mail
		$this->load->library('mail_lib');
        $this->mail_lib->act_aff($email,$detail->nama_panggilan,$detail->password,$link_login);

		$data['ok'] = true;$data['msg'] = lang('actv_ok');
		$this->template->set_view ('reg_act',$data,config_item('modulename_home'));
	}
}
