<? if (!defined('BASEPATH')) exit('No direct script access allowed');
class Mtools extends Aff_Controller{
    var $affid;
	function __construct(){
		parent::__construct();
		// check if has login
		$this->login_lib->a_check_not_login();
		/* load lang */
		$this->lang->load('aff',$this->globals->lang);
		/* load model */
		$this->load->module_model(config_item('modulename'), 'mtools_model', 'mm');
        $this->load->module_model(config_item('modulename'), 'global_model', 'gm');

		/* header description */
		$data['title'] 			= config_item('site_title');
		$data['keyword'] 		= config_item('site_keyword');
		$data['description'] 	= config_item('site_desc');
		$this->template->set_params($data);
	    #$this->template->set_layout('index',config_item('modulename'));
        $this->affid =$this->login_lib->a_get_data('id');

		/* to check system speed and query --> just for admin */
		#$this->output->enable_profiler(TRUE);
	}
	function index($ajax=false){
        $this->load->library('encrypt');
        $data['key_enc'] = config_item('secret_key_banner');
        #$se = serialize(array('data'=>'baru','lagi'=>'aja'));
        #$bl=$this->encrypt->encode($se,$data['key_enc']);
        #echo $bl.'****';
        #print_r(unserialize($this->encrypt->decode($bl,$data['key_enc'])));
		
        if($ajax){
            $this->template->clear_layout();
            $idbn = $this->input->post('idbn');
            $track = $this->input->post('trc');
            $jkat = $this->input->post('kbn'); // baru ada 2 jenis, buku dan sepatu
            // echo $idbn;
			// echo $track;
			// echo $jkat;
			$iklan = $this->mm->has_create_iklan($idbn,$this->affid,$track);
            if(!$iklan){
                $id_iklan = $this->mm->create_iklan($idbn,$this->affid,$track); // jenis banner
                $echo['msg'] = lang('banner_success');
            }else{
                $id_iklan = $iklan;
                $echo['msg'] = lang('banner_has_create');
            }#echo $id_iklan.'-'.$data['key_enc'];break;
			//echo $id_iklan;
			//print_r ($data['key_enc']);
            $echo['script'] = banner_code($this->encrypt->encode($id_iklan,$data['key_enc']),$jkat);
            echo json_encode($echo);
        }else{
            $data['option_track']=$this->mm->option_track(true,$this->affid,true);
		    $this->template->set_view ('mtools_banner',$data,config_item('modulename'));
        }
	}
    function track($ajax=false){
  		// paging
  		$this->load->helper('pagenav');
  		$pg 				= GetPageNLimitVar(false,20); #print_r($pg);
  		$paging['curpage'] 	= $this->input->post('start')!=''?$this->input->post('start'):$pg['curpage'];
  		$paging['limit'] 	= $pg['limit'];
  		$paging['total'] 	= $this->mm->list_track($this->affid,false,false,true);
  		$obj				= CreatePageNav($paging);
  		$limitstart 		= GetLimitStart($paging['curpage'],$paging['limit']); #echo $limitstart;break;
  		$data['paging'] 	= $obj;
  		$data['thislink'] 	= false;#config_item('modulename').'/'.$this->router->class.'/'.$this->router->method;
  		$data['limit'] 		= $paging['limit'];
  		$data['startnumber']= $limitstart;
        $data['list_track'] = $this->mm->list_track($this->affid,$limitstart,$paging['limit']);

        if($ajax=='1'){
            $this->template->clear_layout();
            $this->template->set_view ('mtools_track2',$data,config_item('modulename'));
        }else
        $this->template->set_view ('mtools_track',$data,config_item('modulename'));
    }
    function updatetrack(){
        $this->template->clear_layout();
        if($this->input->post('do_update')){
            $id=$this->input->post('idtr');
            $aktif=$this->input->post('status');
            if($this->mm->update_track($this->affid,$id,$aktif)) echo '1';
        }else
            echo '0';
    }
    function edittrack($track=false){
        if(!$track) redirect(config_item('modulename').'/mtools/track');
        if($this->input->post('_EDIT')){
            $id = $this->input->post('idt');
            $tn = $this->input->post('tname');
            $is = $this->input->post('isactive');
            if($this->mm->update_track($this->affid,$id,$is,$tn)){
                $data['ok'] = true;$data['msg'] = lang('update_success');
            }else{
                $data['ok'] = false;$data['msg'] = lang('update_error');
            }
        }
        $data['detail'] = $this->mm->detail_track($this->affid,$track);
        if($data['detail']){
            $this->template->set_view ('mtools_track_edit',$data,config_item('modulename'));
        }else{
            java_alert(lang('no_data_track'));
            redirect_java(config_item('modulename').'/mtools/track');
        }
    }
    function addtrack(){
        $idt=false;$data=false;
        if($this->input->post('_ADD')){
            $tn = $this->input->post('tname');
            $is = $this->input->post('isactive');
            if(($idt=$this->mm->add_track($this->affid,$is,$tn))){
                $data['ok'] = true;$data['msg'] = lang('add_success');
            }else{
                $data['ok'] = false;$data['msg'] = lang('add_error');
            }
        }
        if($idt)
        $data['detail'] = $this->mm->detail_track($this->affid,$idt);
        $this->template->set_view ('mtools_track_edit',$data,config_item('modulename'));
    }
    function delltrack($idtrack=false){
        #if(!$idtrack)
    }
    function linkproduk($ajax=false){
		if($ajax)
		{
			$this->template->clear_layout();
			if($ajax=='2')
			{
				$kat=$this->input->post('kat');
				$subkat=$this->input->post('subkat');
				$key=$this->input->post('key');
				// sebelum di simpan di table data, serialize dahulu
				$data_box=false;
				if(!empty($kat)) $data_box['kat']=$kat;
				if(!empty($subkat)) $data_box['subkat']=$subkat;
				if(!empty($key)) $data_box['key']=$key;

				$this->load->library('encrypt');
				$data['key_enc'] = config_item('secret_key_lp');
				
				$idbox = $this->input->post('idbox');
				$track = $this->input->post('trc');
				$iklan = $this->mm->has_create_iklan($idbox,$this->affid,$track,'2');
				if(!$iklan){
					$id_iklan = $this->mm->create_iklan($idbox,$this->affid,$track,'2');
					// add data jika ada
					if($data_box){ 
						$ser_data_box=serialize($data_box);
						$this->mm->add_data_iklan($id_iklan,$ser_data_box);
					}
					$echo['msg'] = lang('lp_success');
				}else{
					// cek iklan data, jika ada update jika tidak insert
					$id_iklan = $iklan;
					if($this->mm->get_data_iklan_by_idiklan($id_iklan)){
						$ser_data_box=serialize($data_box);
						$this->mm->update_data_iklan($id_iklan,$ser_data_box);
					}else{
						$ser_data_box=serialize($data_box);
						$this->mm->add_data_iklan($id_iklan,$ser_data_box);
					}
					$echo['msg'] = lang('lp_has_create');
				}
				$echo['script'] = lp_code($this->encrypt->encode($id_iklan,$data['key_enc']));
				echo json_encode($echo);
				
			}else{
				$search['kat']=$this->input->post('kat');
				$search['subkat']=$this->input->post('subkat');
				$search['key']=$this->input->post('key');
				$data['data_for_ajax']='';
				if(!empty($search['kat']))$data['data_for_ajax'].='&kat='.$search['kat'];
				if(!empty($search['subkat']))$data['data_for_ajax'].='&subkat='.$search['subkat'];
				if(!empty($search['key']))$data['data_for_ajax'].='&key='.$search['key'];
				
				$data['option_track']=$this->gm->option_track(true,$this->affid,true);
				$data['list_produk'] = $this->mm->get_produk_for_linkproduk($search);
				$this->template->set_view ('mtools_linkproduk2',$data,config_item('modulename'));
			}
		}else{
			$data['option_kat'] = $this->gm->option_kat();
			$this->template->set_view ('mtools_linkproduk',$data,config_item('modulename'));
		}
	}
	function hascreated(){
		$data['list_iklan']=false;
		$this->template->set_view ('mtools_created',$data,config_item('modulename'));
	}
}
