<? if($this->router->method!='imp') {?>
<h3><?=$name?></h3>
<? }?>

<div style="border:1px solid #ccc;margin-top:10px;width:<?=$width?>px;min-height:<?=$height?>px;background-color:#fff;">
	<div style="padding-top:3px;border-bottom:1px solid #ccc;text-align:center;background-color:#283762;"><?=loadimg('logo-headeraff.jpg',array('style'=>'width:130px;52px;'))?></div>
	

<? if($text_position=='right'){
	#$count=$banyak_group=0;
	$wd='';
	if(isset($width_produk)){
		$wd='width:'.$width_produk;
	}
	$width_img=$height_img=90;
	if(isset($wimg))$width_img=$wimg;
	if(isset($himg))$height_img=$himg;

	/*$cgroup=0;
	if(isset($jml_side))$cgroup=$jml_side; #print_r($_list_produk);

	// looping dan kumpulkan produk sesuai dgn jml_side dan jml_produk yg ada di config produk
	foreach($_list_produk as $ls){$count++;$banyak_group++;
		// price
		$hb=get_price($ls->ha_prop,$ls->hb_prop,$ls->ha_diskon,$ls->hb_diskon);
		if($hb==0)$hb=$ls->ha_prop;		

		// link for write klik iklan jika dari method 'imp'
		if($this->router->method=='imp')
		$link_lp = site_url(config_item('link_lp_klk').'/'.$ls->id.'/'.$id_iklan_crypt.'/'.en_url_save($ls->nama_produk));
		else
		$link_lp = 'javascript:void();';

		$gbr=unserialize($ls->gambar);
		$gb=isset($gbr['intro'])?$gbr['intro']:false; 


		if($gb){?>
			
			<table style="padding:0;margin:0;float:left;margin:3px;list-style:none;text-align:left;<?=$wd?>"><tr><td style="vertical-align:top">
				<a href="<?=$link_lp?>" title="<?=$ls->nama_produk?>">
				<?=loadImgProduk($ls->id.'/'.$ls->idgbr.'/'.$gb,array('style'=>'border:none;width:'.$width_img.'px;height:'.$height_img.'px;margin:0 3px 0 0;'))?>
				</a>
			</td><td style="vertical-align:top;">			
				<a href="<?=$link_lp?>" style="font-size:12px;"><?=$ls->nama_produk?></a><br />
				<span style="color:#FF5A03;font-size:12px;">Rp. <?=currency($hb)?></span><br />
 				<a href="<?=$link_lp?>"><?=loadimg('button_buy.png',array('style'=>'width:75px;height:23px;'),FALSE,FALSE,TRUE)?></a>
			</td></tr></table>
			
			<? 
			if($cgroup!=0){
				if($banyak_group==$cgroup){
					echo '<br style="clear:both;" />';
					$banyak_group=0;
				}
			}
		}
		if($count==$jml_produk)break;
	}*/

	// hitung jumlah baris tabel produknya
	$jml_baris_table=$jml_produk/$jml_side;
	// looping jml table tersebut
	for($jj=0;$jj<$jml_baris_table;$jj++){
		// jml segment produk, artinya ada berapa baris produk yg tampil
		$segment_produk=$jj*$jml_side;
		// open table
		echo '<center><table><tr>';
		// looping jml td berdasarkan jml produk dalam satu baris table
		for($jj2=0;$jj2<$jml_side;$jj2++){if(isset($_list_produk[($segment_produk+$jj2)])){
			// ambil data produk sesuai urutan
			$ls=$_list_produk[($segment_produk+$jj2)]; 
			// jika dari controller impresi, maka aktifkan linknya
			if($this->router->method=='imp')
			$link_lp = site_url(config_item('link_lp_klk').'/'.$ls->id.'/'.$id_iklan_crypt.'/'.en_url_save($ls->nama_produk));
			else
			$link_lp = 'javascript:void();';
			// define img
			$gbr=unserialize($ls->gambar);
			$gb=isset($gbr['intro'])?$gbr['intro']:false; 
			// show img
			echo '<td rowspan="3" style="vertical-align:top;'.$wd.'">';
				echo '<a href="$link_lp" title="$ls->nama_produk">';
				echo loadImgProduk($ls->id.'/'.$ls->idgbr.'/'.$gb,array('style'=>'border:none;width:'.$width_img.'px;height:'.$height_img.'px;margin:0 3px 0 0;'));
				echo '</a>';
			echo '</td>';
			// show nama produk
			echo '<td style="vertical-align:top;'.$wd.'"><a href="'.$link_lp.'" style="font-size:12px;">'.$ls->nama_produk.'</a></td>';
		}}
		echo '</tr><tr>';
		// looping jml td berdasarkan jml produk dalam satu baris table
		for($jj3=0;$jj3<$jml_side;$jj3++){if(isset($_list_produk[($segment_produk+$jj3)])){
			// ambil data produk sesuai urutan
			$ls=$_list_produk[($segment_produk+$jj3)];
			// price
			$hb=get_price($ls->ha_prop,$ls->hb_prop,$ls->ha_diskon,$ls->hb_diskon);
			if($hb==0)$hb=$ls->ha_prop;		
			// show price
			echo '<td><span style="color:#FF5A03;font-size:12px;">Rp. '.currency($hb).'</span></td>';
		}}
		echo '</tr><tr>';
		// looping jml td berdasarkan jml produk dalam satu baris table
		for($jj4=0;$jj4<$jml_side;$jj4++){if(isset($_list_produk[($segment_produk+$jj4)])){
			// ambil data produk sesuai urutan
			$ls=$_list_produk[($segment_produk+$jj4)];
			// jika dari controller impresi, maka aktifkan linknya
			if($this->router->method=='imp')
			$link_lp = site_url(config_item('link_lp_klk').'/'.$ls->id.'/'.$id_iklan_crypt.'/'.en_url_save($ls->nama_produk));
			else
			$link_lp = 'javascript:void();';
			// show buton buy
			echo '<td><a href="'.$link_lp.'">'.loadimg('button_buy.png',array('style'=>'border:none;width:75px;height:23px;'),FALSE,FALSE,TRUE).'</a></td>';
		}}
		// close table
		echo '</tr></table></center>';
		if($jml_baris_table>1) echo '<div style="border-bottom:1px solid #efefef;height:5px;"></div>';
	}

}else{?>
<ul style="padding:0;margin:0;">
	<? $count=0;foreach($_list_produk as $ls){$count++;
		// price
		$hb=get_price($ls->ha_prop,$ls->hb_prop,$ls->ha_diskon,$ls->hb_diskon);		
		if($hb==0)$hb=$ls->ha_prop;

		// link for write klik iklan jika dari method 'imp'
		if($this->router->method=='imp')
		$link_lp = site_url(config_item('link_lp_klk').'/'.$ls->id.'/'.$id_iklan_crypt.'/'.en_url_save($ls->nama_produk));
		else
		$link_lp = 'javascript:void();';

		$gbr=unserialize($ls->gambar);
		$gb=isset($gbr['intro'])?$gbr['intro']:false; 
		if($gb){?>
			<li style="margin:3px;list-style:none;text-align:center;">
				<a href="<?=$link_lp?>" style="font-size:12px;"><?=$ls->nama_produk?></a><br />				
				<a href="<?=$link_lp?>" title="<?=$ls->nama_produk?>">
				<?=loadImgProduk($ls->id.'/'.$ls->idgbr.'/'.$gb,array('style'=>'border:none;width:90px;height:90px;margin:3px 0 3px 0;'))?>
				</a><br />
				<span style="color:#FF5A03;font-size:12px;">Rp. <?=currency($hb)?></span><br />
				<a href="<?=$link_lp?>"><?=loadimg('button_buy.png',array('style'=>'border:none;width:75px;height:23px;'),FALSE,FALSE,TRUE)?></a>
			</li>
		<? }?>
	<? if($count==$jml_produk)break;}?>
</ul>
<? }?>

<br style="clear:both;" />
</div>
