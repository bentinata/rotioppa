<h3 style="width:450px"><?=lang('send_pass')?></h3>
<br />
<style>.tell td{line-height:30px;}.view_msg{color:#FF0000;}</style>
<div class="boxq">
<div class="view_msg"></div>
<div id="small_load" class="hide"><center><?=loadImg('small-loader.gif')?></center></div>

<table class="tell">

<tr><td><?=lang('your_mail')?></td><td><input type="text" name="email_a" /></td></tr>
<tr><td><?=lang('verify_code')?></td><td>
	<img src="<?=base_url().'captcha'?>" width="80px" height="30px" style="position:relative;top:8px;margin-right:10px;" />
	<input type="text" class="captcha" name="captcha_f" />
</td></tr>
<tr><td>&nbsp;</td><td><input id="kirim_pass" type="button" name="_KIRIM" value="<?=lang('send_now')?>" /></td></tr>
</table>
<br />

<script type="text/javascript">
$(document).ready(function() {
	$('#kirim_pass').click(function(){
		em=$("input[name='email_a']").val();
		cp=$("input[name='captcha_f']").val();
		if(em!='' && cp!=''){
			$.ajax({
				type: "POST",
				url: "<?=site_url('aff/home/forgetpass')?>",
				data: "send_mail=1&captcha="+cp+"&email="+em,
				beforeSend: function(){
					$('#small_load').show();
				},
				success: function(msg){ //alert(msg);
					$('#small_load').hide();
					$('.view_msg').html(msg.msg);
					if(msg.res=='1') $('#kirim_pass').attr('disabled',true)
				},
				error: function(){
					$('#small_load').hide();
					$('.view_msg').html('Proses gagal.');
				},
				dataType: "json"
			});
		}else alert('<?=lang('data_must_fill')?>');
	});
});
</script>