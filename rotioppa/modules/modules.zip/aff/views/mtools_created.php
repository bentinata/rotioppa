<?=$this->load->module_view(config_item('modulename'),'head_aff')?>

<h3>kldjfkdj</h3><br />
<fieldset>
<legend>banner</legend><br />
<center>
<? 
$klb=1;
$array_for_view=array('img_banner'=>'buku/120_240.png');
		$this->load->view('mtools_banner_view',$array_for_view);?>
		<div class="banner_code" style="background-color:#fff">
		<p><?=lang('kode_track').': <b>'.$lb->track.'</b>'?></p>
		<p>kode</p>
		<p><textarea name="hasil_gen" class="banner_code_area" id="code_<?=$klb?>">fdjfdkjf</textarea></p>
		</div><br />

</center>
</fieldset>