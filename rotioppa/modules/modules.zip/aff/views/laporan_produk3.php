<? if($list_produk){$i=$startnumber;foreach($list_produk as $lk){$i++;?>
<tr class="<?=($i%2)==1?'row0':'row1'?>">
	<td><?=$i?></td>
	<td><?=format_date($lk->dt,'00-00-0000','-')?></td>
	<td><?=$lk->subkategori?></td>
	<td><?=$lk->track?></td>
	<td><?=$lk->nama_produk?></td>
	<td><?=$lk->jml?></td>
	<td><?=currency($lk->harga)?></td>
	<td><?=currency($lk->kom)?></td>
</tr>
<? }}?>
