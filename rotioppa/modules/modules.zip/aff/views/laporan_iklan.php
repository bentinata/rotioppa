<br />
<table class="adminlist">
<thead>
<tr>
	<th class="no"><?=lang('no')?></th>
	<th><?=lang('tgl')?></th>
	<th><?=lang('banner_name')?></th>
	<th><?=lang('jenis_iklan')?></th>
	<th><?=lang('id_track')?></th>
	<th><?=lang('impresi')?></th>
	<th><?=lang('klik')?></th>
	<th><?=lang('ctr')?></th>
	<th><?=lang('sales')?></th>
	<th><?=lang('spc')?></th>
</tr>
</thead>
<tbody id="viewajax">
<? $this->template->load_view('laporan_iklan2',false,config_item('modulename'))?>
</tbody>
<tfoot>
<tr>
	<td colspan="10">	
	<div class="pagination">
	<?=lang('page')?> <?=$paging->LimitBox('page','class="paging"',$thislink)?> <?=lang('from')?> <?=$paging->total_page?>
	</div>
	</td>
</tr>
</tfoot>
</table>
<p style="text-align:right"><?=lang('dl')?> [ Excel/HTML ]</p>

<script language="javascript">
$(function(){
	$("select[name='page']").val($('option:first', $("select[name='page']")).val());

	$('.paging').change(function(){
		$.ajax({
			type: "POST",
			url: "<?=site_url(config_item('modulename').'/'.$this->router->class.'/lapiklan/1')?>",
			data: "start="+$(this).val()+"&<?=$forajax?>",
			beforeSend: function(){
				$('#viewajax').html($('#bigload').html());
			},
			success: function(msg){ //alert(msg);
				$('#viewajax').html(msg);
			}
		});
	});

});
</script>
