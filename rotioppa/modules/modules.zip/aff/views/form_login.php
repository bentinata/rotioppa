<div class="space_blog">
	<div class="form_pendaftaran_mitra" style="border:none">
	
		<div class="head">
			<img src="<?=theme_img('Affiliate_07.png',false)?>"> Login Affiliate
		</div>
		
		<div class="form-input" style="background:#eaf2f9; padding:0;">
			<ul>
				<form method="post" action="<?=site_url('login/aff')?>" id="form-login-aff">
					<ul class="form" style="padding:0">
						<li><input id="mail-aff" style="width:92%; padding:4%" type="text" name="email" placeholder="Email" /></li>
						<br>
						<li><input id="pass-aff" style="width:92%;padding:4%"type="password" name="password" placeholder="Password"/></li>
						<br>
						<li><button id="a-login"><b>Login</b></button></li>
						</ul>
						<br>
					<span style="font-size:14px">Belum Terdaftar? <a style="color:#ff3657;" href="<?=site_url('aff/reg')?>">Daftar Disini</a></span>
				</form>
			</ul>
		</div>
		
	</div>		
</div>
<!-- lib for fancy -->
<?=loadJs('fancybox/jquery.fancybox-1.3.0.pack.js',false,true)?>
<?=loadCss('js/fancybox/jquery.fancybox-1.3.0.css',false,true,false,true)?>

<style>
.form label{text-align:left;font-style:normal;}
</style>
<script type="text/javascript">
$(document).ready(function() {
	$("#mail-aff,#pass-aff").keypress(function(e){
		if(e.which==13){
			$("#a-login").trigger('click');
		}
	});
	$('#a-login').click(function(){
		if($('#mail-aff').val()!='' && $('#pass-aff').val()!=''){ 
			$('#form-login-aff').submit();
			return true;
		}
		alert('<?=lang('mail_pass_must_fill')?>');
		return false;
	});
	$('#forget_pass').click(function(){
		$.fancybox({
			'transitionIn'		: 'elastic',
			'transitionOut'		: 'elastic',
			'hideOnOverlayClick': false,
			'href':'<?=site_url(config_item('modulename').'/home/forgetpass')?>',
			'ajax':{
				type	: "POST",
				data	: "forget=yes"
			}
		});
		return false;
	});

});
</script>
