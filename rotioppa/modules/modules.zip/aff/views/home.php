	<div class="judul">
		AFFILIATE
	</div>
	<div class="garis"></div>
<div id="kemitraan">
	<ul>
		<li class="box_content">
			<div>
				<img src="<?=theme_img('Affiliate_03.png',false)?>">
			</div>
			<br>
			<div class="space_blog">
				<div class="form_pendaftaran_mitra">
						<div class="head">
							<img src="<?=theme_img('Affiliate_07.png',false)?>"> Pertanyaan Terkait
						</div>
						<div class="form-input">
							<ul>
								<!-- seri manual -->
								<li><a href="<?=site_url('aff/faq')?>">1. Apa itu Affiliate System</a></li>
								<li><a href="<?=site_url('aff/faq')?>">2. Berapa Komisi yang akan di dapatkan member Affiliate apabila telah berhasil menjual produk Naylakidz</a></li>
								<li><a href="<?=site_url('aff/faq')?>">3. Kapan Komisi Affiliate akan diberikan</a></li>
								<li><a href="<?=site_url('aff/faq')?>">4. Berapa besar minimal komisi pembayaran yang dapat dipilih oleh member Affiliate</a></li>
								<li><a href="<?=site_url('aff/faq')?>">5. Apa saja metode pembayaran komisi Affiliate yang disediakan di Naylakidz</a></li>
								</ul>
						</div>
				</div>		
			</div>
		</li>
	</ul>	
	<ul>	
		<li id="sisi">
			<div>
				<ul>
					<li id="block-sidebar_kanan" class="rightside width-sidebar">
						<?=$template['partials']['pg_login'];?>
					</li>
				</ul>
			</div>
		</li>
	</ul>
</div>