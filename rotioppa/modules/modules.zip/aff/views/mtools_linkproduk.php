<?=$this->load->module_view(config_item('modulename'),'head_aff')?>
<h3><?=lang('link_produk')?></h3><br />
<fieldset class="boxq boxqbg2 boxlp"><legend><?=lang('option_link_produk')?></legend>
        <?=lang('lp_kat')?> 
	<?=form_dropdown('kat',$option_kat,false,'id="lp_kat"')?> 
	<?=lang('lp_subkat')?> 
	<select name="" id="lp_subkat"></select> <span id="load_lp_subkat"></span>
	<?=lang('lp_key')?> 
        <input id="lp_key" type="text" name="lp_key" /> 
        <input id="_OK" type="button" name="_OK" value="<?=lang('lp_ok')?>" />
</fieldset>
<br />
<span id="load_lp"></span>
hallo
<span id="smalload" class="hide"><?=loadImg('small-loader.gif')?></span>
<script language="javascript">
$(function(){
	$('#lp_kat').change(function(){ 
		var thisid=$(this).val();
		if(thisid!=''){
			$.ajax({
				type: "POST",
				url: "<?=site_url(ci()->module.'/aff/get_subkat_byidkat')?>",
				data: "idkat="+thisid,
				beforeSend: function(){
					$('#lp_subkat').hide();
					$('#load_lp_subkat').html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('#load_lp_subkat').html('');
					$('#lp_subkat').html(msg).show();
				}//,
				//dataType: 'json'
			});
		}
	}).val($('option:first', $('#lp_kat')).val());
	$('#_OK').click(function(){
		var kat=$('#lp_kat').val();
		var subkat=$('#lp_subkat').val();
		var key=$('#lp_key').val();
		var plus='';
		if(kat)plus+='&kat='+kat;
		if(subkat)plus+='&subkat='+subkat;
		if(key)plus+='&key='+key;
			$.ajax({
				type: "POST",
				url: "<?=site_url(ci()->module.'/'.ci()->class.'/'.ci()->method.'/1')?>",
				data: "go=1"+plus,
				beforeSend: function(){
					$('#load_lp').html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('#load_lp').html(msg);
				}//,
				//dataType: 'json'
			});
	});

	$('.banner_code_area').live('click',function(){
		$(this).select();
	});
	$('.gen_banner').live('click',function(){
		loop=$(this).attr('loop');
		trc=$('#trc_'+loop).val();
		if(trc!='' && trc!='-'){
			$.ajax({
				type: "POST",
				url: "<?=site_url(ci()->module.'/'.ci()->class.'/index/1')?>",
				data: "idbn="+$(this).attr('idgen')+"&trc="+trc,
				beforeSend: function(){
					$('#loadBanner_'+loop).html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('#loadBanner_'+loop).html(msg.msg);
					$('#code_'+loop).val(msg.script);
				},
				dataType: 'json'
			});
		}else{
			alert('<?=lang('track_must_select')?>');
		}
	});
});
</script>