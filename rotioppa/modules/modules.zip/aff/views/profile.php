<?
for($t=1;$t<=date('j');$t++){$tgl[$t]=$t;}
for($b=1;$b<=12;$b++){$bln[$b]=$b;}
for($y=1970;$y<=(date('Y')-10);$y++){$year[$y]=$y;}
$minkom = config_item('min_komisi');
$part=explode('-',$aff->tgl_lahir);
?>
<?=$this->load->view('head_aff')?>

<form method="post" action="">
<h3><?=lang('info_aff')?></h3><br />

<div class="boxq faq boxqbg2">
<? if(isset($ok)){?><div class="<?=$ok?'msg_success':'msg_error'?>"><?=$msg?></div><? }?>
<ul class="form">
	<li><label><?=lang('email')?> </label>: <b><?=$aff->email?></b></li><br>
	<li><label><?=lang('pass')?> </label>: <input type="password" name="password" value="<?=$aff->password?>" /></li><br>
	<li><label><?=lang('repass')?> </label>: <input type="password" name="password2" value="<?=$aff->password?>" /></li><br>
	<li><label><?=lang('fullname')?> </label>: <input type="text" name="fullname" value="<?=$aff->nama_lengkap?>" /></li><br>
	<li><label><?=lang('nickname')?> </label>: <input type="text" name="nickname" value="<?=$aff->nama_panggilan?>" /></li><br>
	<li><label><?=lang('tlp')?> </label>: <input type="text" name="tlp" value="<?=$aff->no_tlp?>" /></li><br>
	<li><label><?=lang('hp')?> </label>: <input type="text" name="hp" value="<?=$aff->no_hp?>" /></li><br>
	<li><label><?=lang('alamat')?> </label>: <input type="text" name="alamat" value="<?=$aff->alamat?>" /></li><br>
	<li><label><?=lang('kota')?> </label>: <input type="text" name="kota" value="<?=$aff->kota?>" /></li><br>
	<li><label><?=lang('prov')?> </label>: <input type="text" name="prov" value="<?=$aff->provinsi?>" /></li><br>
	<li><label><?=lang('negara')?> </label>: <input type="text" name="negara" value="<?=$aff->negara?>" /></li><br>
	<li><label><?=lang('jenkel')?> </label>: <?=form_dropdown('jenkel',config_item('jenkel'),$aff->jen_kel)?></li><br>
	<li><label><?=lang('tgl_lahir')?> </label>: Tgl <?=form_dropdown('tgl',$tgl,$part[2])?> Bln <?=form_dropdown('bln',$bln,$part[1])?> Thn <?=form_dropdown('thn',$year,$part[0])?></li><br>
	<li><label><?=lang('pay_method')?> </label>: <input id="c1" name="paymethod" value="1" type="radio" <?=$aff->pay_method=='1'?'checked="checked"':''?> /> Transfer Antar Bank &nbsp;&nbsp;<input id="c2" name="paymethod" type="radio" value="2" <?=$aff->pay_method=='2'?'checked="checked"':''?> /> Paypal</li><br>
	<li><label><?=lang('min_komisi')?> </label>: <?=form_dropdown('minkom',$minkom,$aff->min_transfer)?></li><br>
</ul>
<br />
</div><br />

<input type="submit" name="_SAVE" value="<?=lang('update_data')?>" />
</form>
<script language="javascript">
$(function(){
	$('.form label').css('width','150px');
})
</script>
