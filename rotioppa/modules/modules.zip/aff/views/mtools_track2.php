<? if($list_track){$i=$startnumber;foreach($list_track as $lk){$i++;?>
<tr class="<?=($i%2)==1?'row0':'row1'?>">
	<td><?=$i?></td>
	<td><?=$lk->track?></td>
	<td><span class="view_<?=$lk->id?>"><?=lang('track_aktive_'.$lk->is_active)?></span><span class="load_<?=$lk->id?>"></span></td>
	<td>
	[ <a href="javascript:void(0)" val="1" id="<?=$lk->id?>" class="act"><?=lang('do_active')?></a> ]
	[ <a href="javascript:void(0)" val="2" id="<?=$lk->id?>" class="act"><?=lang('do_noactive')?></a> ]
	[ <a href="<?=site_url(config_item('modulename').'/mtools/edittrack/'.$lk->id)?>" class="act_edit"><?=lang('edit')?></a> ]
	</td>
</tr>
<? }}?>
<span id="val_1" class="hide"><?=lang('track_aktive_1')?></span>
<span id="val_2" class="hide"><?=lang('track_aktive_2')?></span>
<script language="javascript">
$(function(){
	$('.act').click(function(){
		id=$(this).attr('id');
		vl=$(this).attr('val');
		ctval=$('#val_'+vl).html();
		$.ajax({
			type: "POST",
			url: '<?=site_url(config_item('modulename').'/'.$this->router->class.'/updatetrack')?>',
			data: "do_update=1&idtr="+id+"&status="+vl,
			beforeSend: function(){
				$('.view_'+id).hide();
				$('.load_'+id).html($('#smallload').html());
			},
			success: function(msg){ //alert(msg);
				$('.load_'+id).html('');
				if(msg=='1'){
					$('.view_'+id).html(ctval).show();
					alert('<?=lang('track_has_update')?>');
				}else{
					alert('<?=lang('track_fail_update')?>');
					$('.view_'+id).show();
				}
			}
		});
		return false;
	});

});
</script>
