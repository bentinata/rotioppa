<?=$this->load->view('head_aff')?>

<div class="column" style="width:75%">
	<fieldset class="boxq akun boxqbg2">
		<legend><?=lang('akun_aff')?></legend>
		<ul class="form">
			<li><label><?=lang('email')?> </label>: <b><?=$aff->email?></b></li>
			<li><label><?=lang('pass')?> </label>: <?='******'?> ( <?=lang('lost_pass')?> <?=anchor(config_item('modulename').'/'.$this->router->class.'/sendtomail',lang('send_to_mail'),array('style'=>'text-decoration:underline','class'=>'sendmail'))?> )</li>
			<li><label><?=lang('fullname')?> </label>: <?=$aff->nama_lengkap?></li>
			<li><label><?=lang('nickname')?> </label>: <?=$aff->nama_panggilan?></li>
		</ul>	
	</fieldset>
	<a href="<?=site_url(config_item('modulename').'/profile')?>" class="orange"><?=lang('lengkap')?></a>	
	<br /><br />

	<h3><?=lang('report_last_7day')?> ( <?=format_date_ina($date1,'-',' ')?> - <?=format_date_ina($date2,'-',' ')?> )</h3><br />
	<fieldset class="boxq"><legend><?=lang('lap_iklan')?></legend>
	<table class="adminlist">
	<thead>
	<tr>
		<th class="no"><?=lang('no')?></th>
		<th><?=lang('tgl')?></th>
		<th><?=lang('banner_name')?></th>
		<th><?=lang('jenis_iklan')?></th>
		<th><?=lang('id_track')?></th>
		<th><?=lang('impresi')?></th>
		<th><?=lang('klik')?></th>
		<th><?=lang('ctr')?></th>
		<th><?=lang('sales')?></th>
		<th><?=lang('spc')?></th>
	</tr>
	</thead>
	<tbody id="viewajax">
	<? $this->template->load_view('laporan_iklan2',false,config_item('modulename'))?>
	</tbody>
	</table>
	</fieldset>
	<a href="<?=site_url(config_item('modulename').'/review')?>" class="orange"><?=lang('lengkap')?></a>	
	<br />
	<br />

	<fieldset class="boxq"><legend><?=lang('lap_produk')?></legend>
	<table class="adminlist">
	<thead>
	<tr>
		<th class="no"><?=lang('no')?></th>
		<th><?=lang('tgl')?></th>
		<th><?=lang('subkat')?></th>
		<th><?=lang('id_track')?></th>
		<th><?=lang('nama_produk')?></th>
		<th><?=lang('jml')?></th>
		<th><?=lang('harga')?></th>
		<th><?=lang('komisi')?></th>
	</tr>
	</thead>
	<tbody id="viewajax">
	<? $this->template->load_view('laporan_produk3',false,config_item('modulename'))?>
	</tbody>
	</table>
	</fieldset>
	
	<a href="<?=site_url(config_item('modulename').'/review/lapproduk')?>" class="orange"><?=lang('lengkap')?></a>	
	<br /><br />
	<a href="<?=site_url(config_item('modulename').'/banner/imp')?>" class="orange">haha</a>	
	<fieldset class="boxq boxqbg2"><legend>Informasi Affiliate</legend>
		<? if($info){foreach($info as $if){?>
		<p><?=$if->info?></p><br />
		<? }}?>
	</fieldset><br />

	<fieldset class="boxq boxqbg2"><legend>FAQ</legend>
		<? if($faq){foreach($faq as $fq){?>
		<p>
			<i><?=$fq->question?></i><br />
			<b><?=$fq->answer?></b>
		</p><br />
		<? }}?>
		<ol>
		<!-- seri manual -->
		<li><a href="<?=site_url('aff/faq')?>#aff1">Apa itu Affiliate System</a></li>
		<li><a href="<?=site_url('aff/faq')?>#aff2">Berapa Komisi yang akan di dapatkan member Affiliate apabila telah berhasil menjual produk Samoedra.com</a></li>
		<li><a href="<?=site_url('aff/faq')?>#aff3">Kapan Komisi Affiliate akan diberikan</a></li>
		<li><a href="<?=site_url('aff/faq')?>#aff4">Berapa besar minimal komisi pembayaran yang dapat dipilih oleh member Affiliate</a></li>
		<li><a href="<?=site_url('aff/faq')?>#aff5">Apa saja metode pembayaran komisi Affiliate yang disediakan di Samoedra.com</a></li>
		</ol>
	</fieldset>

</div>

<div class="columnr" style="width:24%">
<?
	/*$dt=explode('-',$this_month);
	$mname=month_name($dt[1]); #print_r($this_komisi);
	if($this_komisi){
		$kom=currency($this_komisi[0]->total_komisi);
	}else $kom=0;*/
?>
	<fieldset id="info" class="boxq boxqbg"><legend><?=lang('komisi_anda') #=$mname.' '.$dt[0]?></legend>
	<br /><p class="komisi_rupiah">Rp. <?=currency($komisi_anda)?>,00</p><br />
	</fieldset>
</div>
<script language="javascript">
$(function(){
	$('.sendmail').click(function(){
		if(confirm('<?=lang('your_pass_to_mail')?>')) return true;
		return false;
	});
});
</script>
