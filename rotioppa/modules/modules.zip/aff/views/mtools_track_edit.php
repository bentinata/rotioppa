<?
$isactive=array('1'=>lang('track_aktive_1'),'2'=>lang('track_aktive_2'));
$tname=$idt = '';
$act = false;
$bt='<input type="submit" name="_ADD" value="'.lang('make_track').'" />';
if(isset($detail) && $detail){
	$tname = $detail->track;
	$act = $detail->is_active;
	$idt = form_hidden('idt',$detail->id);
	$bt='<input type="submit" name="_EDIT" value="'.lang('edit').'" />'.'<input type="button" name="_CANCEL" value="'.lang('cancel').'" />';
}
?>
<?=$this->load->module_view(config_item('modulename'),'head_aff')?>
<form method="post" action="">
<h3><?=lang('edittrack')?></h3><br />
<? if(isset($ok)){?><div class="<?=$ok?'msg_success':'msg_error'?>"><?=$msg?></div><? }?>
<ul class="form">
	<li><label><?=lang('trackname')?> </label>: <input type="text" name="tname" value="<?=$tname?>" /></li>
	<li><label><?=lang('isactive')?> </label>: <?=form_dropdown('isactive',$isactive,$act)?></li>
	<li><label>&nbsp;</label>
	<?=$idt?>
	<?=$bt?>	
	
	</li>
</ul>
</form>
<script language="javascript">
$(function(){
	$("input[name='_CANCEL']").click(function(){
		history.go(-1);
	});
})
</script>

