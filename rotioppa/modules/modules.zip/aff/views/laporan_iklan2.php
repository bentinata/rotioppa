<? 
$config_banner1=config_item('list_banner');
$config_banner2=config_item('list_banner_sepatu');
$config_banner3=config_item('box_linkproduk');
if($list_iklan){$i=$startnumber;
foreach($list_iklan as $lk){$i++;
$nama_iklan='';
if(isset($config_banner1[$lk->id_banner])) $nama_iklan=$config_banner1[$lk->id_banner]['name'];
else if(isset($config_banner2[$lk->id_banner])) $nama_iklan=$config_banner2[$lk->id_banner]['name'];
else if(isset($config_banner3[$lk->id_banner])) $nama_iklan=$config_banner3[$lk->id_banner]['name'];
?>
<tr class="<?=($i%2)==1?'row0':'row1'?>">
	<td><?=$i?></td>
	<td><?=format_date($lk->tgl,'00-00-0000','-')?></td>
	<td><?=$nama_iklan?></td>
	<td><?=jenis_iklan($lk->jenis_iklan)?></td>
	<td><?=$lk->track?></td>
	<td><?=$lk->impresi?></td>
	<td><?=$lk->klik?></td>
	<td><?=($lk->klik==0)?0:round((($lk->klik/$lk->impresi)*100),3)?> %</td>
	<td><?=$lk->sales?></td>
	<td><?=($lk->sales==0)?0:round((($lk->sales/$lk->klik)*100),3)?> %</td>
</tr>
<? }}?>
