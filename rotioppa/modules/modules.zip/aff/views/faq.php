<?=$this->load->module_view(config_item('modulename'),'head_aff')?>

<style>
.faq{line-height:20px;padding:20px 50px;}
</style>

<?=loadImg('faq.jpg',false,FALSE,FALSE,TRUE)?><br /><br />

<div class="boxq faq boxqbg2">
<ul>
<li><a href="#aff1">- Apa itu Affiliate System</a></li>
<li><a href="#aff2">- Berapa Komisi yang akan di dapatkan member Affiliate apabila telah berhasil menjual produk Naylakidz</a></li>
<li><a href="#aff3">- Kapan Komisi Affiliate akan diberikan</a></li>
<li><a href="#aff4">- Berapa besar minimal komisi pembayaran yang dapat dipilih oleh member Affiliate</a></li>
<li><a href="#aff5">- Apa saja metode pembayaran komisi Affiliate yang disediakan di Naylakidz</a></li>
</ul>
<br />
<br />

<strong><h3>FAQ Affiliate :</h3> </strong><br /><br />

<p id="aff1">
<strong>- Apa itu Affiliate System</strong><br />
Affiliate system adalah sistem yang disediakan oleh Naylakidz bagi mereka yang ingin mendapatkan penghasilan tambahan dari Naylakidz dengan membantu menjualkan produk-produk pilihan Naylakidz<br /><br />
</p>
<br />

<p id="aff2">
<strong>- Berapa Komisi yang akan di dapatkan member Affiliate apabila telah berhasil menjual produk Naylakidz </strong><br />
Komisi yang akan di dapatkan oleh para Affiliater Samoedra beragam mulai dari 3 % hingga 40 % dari harga produk yang berhasil di jual. Ada produk yang bisa memberikan komisi hanya Rp. 1000 per- penjualan, tetapi ada pula produk yang bisa memberikan komisi hingga  mencapai lebih dari Rp.  1.000.000 per-penjualan.<br /><br />
</p>
<br />

<p id="aff3">
<strong>- Kapan Komisi Affiliate akan diberikan </strong><br />
Komisi Affiliate akan diberikan kepada Affiliater Samoedra setiap bulannya pada tanggal 5 di awal bulan dengan syarat bahwa komisi affiliate member tersebut sudah mencapai besar minimal komisi yang telah di tentukan oleh affiliate member itu sendiri di Affiliate areanya dan settingan status Pembayaran tidak dalam keadaan "Tunda".<br /><br />
</p>
<br />

<p id="aff4">
<strong>- Berapa besar minimal komisi pembayaran yang dapat dipilih oleh member Affiliate </strong><br />
Besar minimal komisi pembayaran yang dapat dipilih oleh member Affiliate adalah <br />
a.	Rp. 200.000<br />
b.	Rp. 500.000<br />
c.	Rp.1.000.000<br />
d.	Rp. 2.000.000<br />
e.	Rp. 5.000.000<br /><br />
</p>
<br />

<p id="aff5">
<strong>- Apa saja metode pembayaran komisi Affiliate yang disediakan di Naylakidz</strong><br />
Metode pembayaran komisi affiliate yang disediakan di Naylakidz diantaranya adalah transfer antar bank dan transfer melalui account paypal.<br />
</p>

<br />
<br />

<span style="font-size:11px">Tidak menemukan jawaban dari pertanyaan Anda, jangan sungkan untuk mengirimkan pertanyaan Anda ke alamat email support@Naylakidz</span>

</div>
