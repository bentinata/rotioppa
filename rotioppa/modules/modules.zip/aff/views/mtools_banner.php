<?=$this->load->module_view(config_item('modulename'),'head_aff')?>
<?
// foreach($option_track as $v){
	// echo $v;
// }
//print_r $option_track;
if(!$option_track)$option_track=array('-'=>'-');
?>
<h3><?=lang('banner')?></h3><br />

<!-- tabs -->
<ul class="css-tabs" style="display:none;">
	<li><a toid="bbuku" class="current" href="javascript:void(0)">Banner Buku</a></li>
	<li><a toid="bsepatu" class="current" href="javascript:void(0)">Banner Sepatu</a></li>
	<li><a toid="bminuman" class="current" href="javascript:void(0)">Banner Minuman</a></li>
</ul>
<!-- content tabs -->
<div class="css-panes">
	<div class="boxbanner" id="bbuku">
	<center>
	<? if(config_item('list_banner')){?>
	<? foreach(config_item('list_banner') as $klb=>$lb){	
		//print_r($lb);
		$array_for_view=array('img_banner'=>$lb['img']);
			//print_r ($array_for_view);
		$this->load->view('mtools_banner_view',$array_for_view);?>
		<div class="banner_code" style="background-color:#fff">
		<p>
			<?=lang('choose_track').' '.form_dropdown('track',$option_track,false,'id="trc_'.$klb.'"').' '.lang('or_make_new').' ['.anchor(config_item('modulename').'/mtools/track',lang('make_track')).']'?>
		</p>
		<p>
			<input type="button" jenis_kategori="1" class="gen_banner" name="_GEN" idgen="<?=$klb?>" value="<?=lang('generate')?>" loop="<?=$klb?>" />
			<span id="loadBanner_<?=$klb?>"></span>
		</p>
		<p>
			<textarea name="hasil_gen" class="banner_code_area" id="code_<?=$klb?>" rows="10"></textarea>
		</p>
		</div><br />
	<? }
	}
	?>
	</center>
	</div>
	
	<div class="boxbanner" id="bsepatu" style="display:none;">
	<center>
	<? if(config_item('list_banner_sepatu')){?>
	sriww
	<? foreach(config_item('list_banner_sepatu') as $klb=>$lb){?>
		<?=loadImg(config_item('dir_banner').'/'.$lb['img'],'',FALSE,FALSE,TRUE)?>
		<div class="banner_code" style="background-color:#fff">
		<p><?=lang('choose_track').' '.form_dropdown('track',$option_track,false,'id="trc_'.$klb.'"').' '.lang('or_make_new').' ['.anchor(config_item('modulename').'/mtools/track',lang('make_track')).']'?></p>
		<p><input type="button" jenis_kategori="2" class="gen_banner" name="_GEN" idgen="<?=$klb?>" value="<?=lang('generate')?>" loop="<?=$klb?>" /><span id="loadBanner_<?=$klb?>"></span></p>
		<p><textarea name="hasil_gen" class="banner_code_area" id="code_<?=$klb?>"></textarea></p>
		</div><br />
	<? }
	}
	?>
	</center>
	</div>
</div>

<span id="smalload" class="hide"><?=loadImg('small-loader.gif')?></span>
<script language="javascript">
$(function(){
$('a','.css-tabs').click(function(){
	var toid=$(this).attr('toid');
	// view their box
	$('.boxbanner').hide();
	$('#'+toid).show();
	// set current tab
	$('a','.css-tabs').attr('class','');
	$(this).attr('class','current');
});
	$('.banner_code_area').click(function(){
		$(this).select();
	});
	$('.gen_banner').click(function(){
		loop=$(this).attr('loop');
		trc=$('#trc_'+loop).val();
		post_track='';
		if(trc!='' && trc!='-'){
			post_track='&trc='+trc
		}

			$.ajax({
				type: "POST",
				url: "<?=site_url(ci()->module.'/'.ci()->class.'/index/1')?>",
				data: "idbn="+$(this).attr('idgen')+"&kbn="+$(this).attr('jenis_kategori')+post_track,
				beforeSend: function(){
					$('#loadBanner_'+loop).html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('#loadBanner_'+loop).html(msg.msg);
					$('#code_'+loop).val(msg.script);
				},
				dataType: 'json'
			});
		//}else{
		//	alert('<?=lang('track_must_select')?>');
		//}
	});
});
</script>