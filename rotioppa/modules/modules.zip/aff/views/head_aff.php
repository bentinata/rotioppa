<?
$method=$this->router->method; 
$theclass=$this->router->class; 
?>
<h3>Affiliate Area</h3><br /> 
<div class="boxq boxqbg menuaff"> 
	<ul>
	<li class="left <?=($theclass=='aff' and $method=='index')?'sl':''?>">
		<a href="<?=site_url(config_item('modulename'))?>"><?=lang('mn_home')?></a></li>
	<li class="<?=$method=='profile'?'sl':''?>">
		<a href="<?=site_url(config_item('modulename').'/profile')?>"><?=lang('akun_aff')?></a></li>
	<li class="<?=$theclass=='mtools'?'sl':''?>">
		<a href="javascript:void(0)" class="opensub" sub="mtools"><?=lang('mtools')?></a></li>
	<li class="<?=$theclass=='review'?'sl':''?>">
		<a href="javascript:void(0)" class="opensub" sub="review"><?=lang('lap')?></a></li>
	<li class="right <?=$theclass=='faq'?'sl':''?>">
		<a href="<?=site_url(config_item('modulename').'/faq')?>"><?=lang('faq')?></a></li>
	</ul>
	<div class="clear"></div>
	
	<p class="submenuaff" id="sub_review">
		<a class="<?=($theclass=='review' && $method=='index')?'sl':''?>" href="<?=site_url(config_item('modulename').'/review')?>"><?=lang('sub_lap_iklan')?></a>
		<a class="<?=$method=='lapproduk'?'sl':''?>" href="<?=site_url(config_item('modulename').'/review/lapproduk')?>"><?=lang('sub_lap_produk')?></a>
		<a class="<?=$method=='lapkom'?'sl':''?>" href="<?=site_url(config_item('modulename').'/review/lapkom')?>"><?=lang('sub_lap_komisi')?></a>
	</p>
	<p class="submenuaff" id="sub_mtools">
		<a class="<?=($theclass=='mtools' && $method=='index')?'sl':''?>" href="<?=site_url(config_item('modulename').'/mtools')?>"><?=lang('sub_mt_banner')?></a>
		<a class="<?=$method=='track'?'sl':''?>" href="<?=site_url(config_item('modulename').'/mtools/track')?>"><?=lang('sub_mt_track')?></a>
		<a class="<?=$method=='linkproduk'?'sl':''?>" href="<?=site_url(config_item('modulename').'/mtools/linkproduk')?>"><?=lang('sub_mt_link')?></a>
		<? /*<a class="<?=$method=='hascreated'?'sl':''?>" href="<?=site_url(config_item('modulename').'/mtools/hascreated')?>"><?=lang('sub_mt_created')?></a>*/?>
	</p>
	
	<div class="clear"></div>
</div>
<div class="clear"></div><br />
<br />

<script language="javascript">
$(function(){
	$('.opensub').toggle(
	function(){
		$('.submenuaff').hide();
		topen=$(this).attr('sub');
		$('#sub_'+topen).slideDown('fast');
	},
	function(){
		topen=$(this).attr('sub');
		$('#sub_'+topen).slideUp('fast');
	}
	);
	$('#sub_<?=$theclass?>').show();
});
</script>