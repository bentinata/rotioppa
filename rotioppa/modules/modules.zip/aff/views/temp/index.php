<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="keywords" content="<?=$keyword?>" />
<meta name="description" content="<?=$description?>" />
<title><?=$title?></title>
<?=loadJs('jquery-1.3.2.min.js',false,true)?>
<?=loadJs('jquery.corner.js',false,true)?>
<?=$customheader?>

</head>
<body> 
<div id="sam-wrap">
	<div id="sam-head">
		<div class="logo"></div>
		<div class="text-head"><div class="text-head2">
			<a href="<?=site_url()?>" class="home" id="bt-home"><?=lang('mn_home')?></a> &nbsp;&nbsp;|&nbsp;&nbsp; 
			<? if($this->login_lib->m_has_login()){?>
			<a href="<?=site_url('member')?>" class="memberarea"><?=lang('mn_member')?></a> &nbsp;&nbsp;|&nbsp;&nbsp; 
			<? }?>
			<? if($this->login_lib->a_has_login()){?>
			<a href="<?=site_url('aff')?>" class="aff"><?=lang('mn_aff')?></a> &nbsp;&nbsp;|&nbsp;&nbsp; 
			<a href="<?=site_url('login/logoutaff')?>" class="logout"><?=lang('mn_logout')?></a>
			<? }else{?>
			<a href="<?=site_url('aff/home')?>" class="login" id="bt-login"><?=lang('mn_login')?></a> &nbsp;&nbsp;
			<? }?>
		</div></div>
	</div>
    
	<? if($this->login_lib->a_has_login()){?>
	<div id="user"><span><b><?=ucfirst($this->login_lib->a_get_data('nama_panggilan'))?></b>, <?=lang('welcome')?> - <?=format_date_ina(date('d m Y'))?></span></div>
	<? }?>
	<div class="clear"></div>
    
	<div id="sam-body">
		<div id="sam-content"><div class="sam-ct">
			<?=$view?>
		</div></div>
	</div>
</div>
<div class="clear"></div>
<br />
<br />

<div id="sam-footer"><? $this->template->load_view('temp/footer')?></div>

<script type="text/javascript">
$(document).ready(function() {
	// square the box
	$('.boxq').corner("5px");$('.img-slider').corner("5px");
});
</script>
</body>
</html>