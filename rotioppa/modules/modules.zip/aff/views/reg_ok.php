<center>
<h3><?=lang('reg_aff')?></h3>
<br />
<br />
<?=loadImg('success.png')?><br />
Registrasi Berhasil, kami telah mengirimkan email, silahkan login <a href="<?=site_url('aff')?>">disini</a>.
</center>