<?=$this->load->module_view(config_item('modulename'),'head_aff')?>
<h3><?=lang('lap_iklan')?></h3><br />

<? $this->template->load_view('laporan_head',false,config_item('modulename'))?>
<br />

<fieldset class="boxq boxqbg2" style="width:600px">
	<legend><?=lang('list_track')?></legend>
	<? if($list_track){foreach($list_track as $tr){?>
	<p><input type="checkbox" class="cek" name="cek" value="<?=$tr->id?>" /> <?=$tr->track?></p>
	<? }}?>
</fieldset>
<br />
<input id="doview" type="submit" name="_VIEW" value="<?=lang('view_lap')?>" />
<input type="hidden" name="track" class="track" value="" />
<br />
<br />

<div id="viewIklan">
<h2><?=lang('report_this_month').' '.month_name(date('m'))?></h2><br />
<? $this->template->load_view('laporan_iklan',false,config_item('modulename'))?>
</div>

<span id="bigload" class="hide"><?=loadImg('big-loader.gif')?></span>
<script language="javascript">
$(function(){
	$("select[name='page']").val($('option:first', $("select[name='page']")).val());
	
	$('.cek').click(function(){
		vt=$('.track').val();
		if(vt!=''){ vt+='-';}
		if($(this).is(':checked')){
			nvt=vt+$(this).val();
		}else{ 
			nn=new Array;
			$('.cek:checked').each(function(i){
				nn[i]=$(this).val();
			});
			nvt=nn.join('-');
		}
		$('.track').val(nvt);
	});

	$('#doview').click(function(){
		tr=$('.track').val();
		tl=$('.tl:checked').val(); 
		if(tl){
			if(tl=='1'){
				tl='&tl='+tl+'&dt='+$("select[name='lap']").val();
			}else{
				t1=$("select[name='thn']").val()+'-'+$("select[name='bln']").val()+'-'+$("select[name='tgl']").val();
				t2=$("select[name='thn2']").val()+'-'+$("select[name='bln2']").val()+'-'+$("select[name='tgl2']").val();
				tl='&tl='+tl+'&dt1='+t1+'&dt2='+t2;
			}
			$.ajax({
				type: "POST",
				url: "<?=site_url(config_item('modulename').'/'.$this->router->class.'/lapiklan/2')?>",
				data: "start=1&track="+tr+tl,
				beforeSend: function(){
					$('#viewIklan').html($('#bigload').html());
				},
				success: function(msg){ //alert(msg);
					$('#viewIklan').html(msg);
				}
			});
		}else
			alert('<?=lang('choose_lap')?>');
	});

});
</script>
