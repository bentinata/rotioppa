<? if($list_iklan){$i=$startnumber;
	foreach($list_iklan as $lk){
		$i++;
	?>
<tr class="<?=($i%2)==1?'row0':'row1'?>">
	<td><?=$i?></td>
	<td><?=format_date_ina($lk->tgl,'-',' ')?></td>
	<td><?=$lk->komisi?></td>
	<!--<td><? #=lang('status_komisi_'.$lk->status_kirim)?></td>-->
</tr>
<? }}?>
