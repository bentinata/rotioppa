<?
for($t=1;$t<=date('t');$t++){$tgl[$t]=$t;}
for($b=1;$b<=12;$b++){$bln[$b]=$b;}
for($y=1970;$y<=(date('Y')-10);$y++){$year[$y]=$y;}
$minkom = config_item('min_komisi');
?>
<?=loadJs('jquery.funtion.global.js',false,true)?>
<form method="post" action="" id="form_reg">
	<div class="judul">
		<?=lang('reg_aff')?>
	</div>
	<div class="garis"></div>
<br>

<div class="faq" style>
<div class="notecolored">* <?=lang('completly')?></div>
<br />
<? if(isset($ok)){?><div class="<?=$ok?'msg_success':'msg_error'?>"><?=$msg?></div><? }?>
<table >
	<tr><td style="width:150px"><?=lang('email')?></td><td style="width:10px">:</td><td><input type="text" class="email_reg" name="email" value="<?=$this->input->post('email')?>" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('pass')?></td><td>:</td><td><input type="password" class="pass_reg" name="password" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('repass')?></td><td>:</td><td><input type="password" class="pass_reg2" name="password2" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('fullname')?></td><td>:</td><td><input type="text" name="fullname" value="<?=$this->input->post('fullname')?>" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('nickname')?></td><td>:</td><td><input type="text" name="nickname" value="<?=$this->input->post('nickname')?>" /><span class="notered">*</span></li>
	<tr><td><?=lang('tlp')?></td><td>:</td><td><input class="numberchar" type="text" name="tlp" value="<?=$this->input->post('tlp')?>" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('hp')?></td><td>:</td><td><input class="numberchar" type="text" name="hp" value="<?=$this->input->post('hp')?>" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('alamat')?></td><td>:</td><td><textarea style="width:300px" name="alamat"><?=$this->input->post('alamat')?></textarea><span class="notered">*</span></td></tr>
	<tr><td><?=lang('kota')?></td><td>:</td><td><input type="text" name="kota" value="<?=$this->input->post('kota')?>" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('prov')?></td><td>:</td><td><input type="text" name="prov" value="<?=$this->input->post('prov')?>" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('negara')?></td><td>:</td><td><input type="text" name="negara" value="<?=$this->input->post('negara')?>" /><span class="notered">*</span></td></tr>
	<tr><td><?=lang('jenkel')?></td><td>:</td><td><?=form_dropdown('jenkel',config_item('jenkel'),$this->input->post('jenkel'))?></td></tr>
	<tr><td><?=lang('tgl_lahir')?></td><td>:</td><td>Tgl <?=form_dropdown('tgl',$tgl,$this->input->post('tgl'))?> Bln <?=form_dropdown('bln',$bln,$this->input->post('bln'))?> Thn <?=form_dropdown('thn',$year,$this->input->post('thn'))?></td></tr>
	<tr><td><?=lang('pay_method')?></td><td>:</td><td><input id="c1" name="paymethod" value="1" type="radio" <?=($this->input->post('paymethod')=='1' or !$this->input->post('paymethod'))?'checked="checked"':''?> /> Transfer Antar Bank &nbsp;&nbsp;<input id="c2" name="paymethod" type="radio" value="2" <?=$this->input->post('paymethod')=='2'?'checked="checked"':''?> /> Paypal</td></tr>
	<tr><td><?=lang('min_komisi')?></td><td>:</td><td><?=form_dropdown('minkom',$minkom,$this->input->post('minkom'))?></td></tr>
	<tr><td><?=lang('weborblog')?></td><td>:</td><td><input style="width:300px;" type="text" name="urlweb" value="<?=$this->input->post('urlweb')?>" /><span class="notered">*</span></td></tr>
	<tr><td>Kode verifikasi</td><td>:</td><td><img src="<?=base_url().'/captcha'?>" width="80px" height="30px" style="position:relative;top:8px;margin-right:10px;" />
		<input type="text" class="captcha" name="captcha" /></td>
		</tr>
	<tr><td colspan="2">&nbsp </td><td>
	<br/><input type="submit" name="_REG" class="aff_isubmit" value="<?=lang('reg_now')?>" />
		</form>
	</td></tr>
</table>
<br />


<br />
</div><br />


<script language="javascript">
$(function(){
	$('.form label').css('width','150px');
	$("input[name='_REG']").click(function(){
		em=$(".email_reg").val();
		ps=$(".pass_reg").val();
		ps2=$(".pass_reg2").val();
		fl=$("input[name='fullname']").val();
		nc=$("input[name='nickname']").val();
		tlp=$("input[name='tlp']").val();
		hp=$("input[name='hp']").val();
		alm=$("textarea[name='alamat']").val();
		cp=$("input[name='captcha']").val();
		pr=$("input[name='prov']").val();
		ng=$("input[name='negara']").val();
		kt=$("input[name='kota']").val();
		web=$("input[name='urlweb']").val();
		if(em!='' && ps!='' && ps2!='' && fl!='' && nc!='' && tlp!='' && hp!='' && alm!='' && cp!='' && kt!='' && pr!='' && ng!='' && web!='')
			$('#form_reg').submit();
		else{
			alert('<?=lang('data_not_complete')?>');
			return false;
		}
	});
})
</script>
