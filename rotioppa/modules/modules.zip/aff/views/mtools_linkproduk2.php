<fieldset class="boxq boxqbg2 boxlp"><legend><?=lang('link_produk')?></legend>
<? 

$list_box=config_item('box_linkproduk');
if($list_produk){foreach($list_box as $idlb=>$lb){
	$array_for_view = array_merge(array('_list_produk'=>$list_produk),$lb);
	?>
	<center><? $this->load->view('mtools_linkproduk_view',$array_for_view)?></center>
	<div class="lp_code" style="background-color:#fff;">
		<? $opt_track=$option_track?form_dropdown('track',$option_track,false,'id="trc_'.$idlb.'"'):'<select name="track"><option value=""></option></select>'?>
		<p><?=lang('choose_track').' '.$opt_track.' '.lang('or_make_new').' ['.anchor(config_item('modulename').'/mtools/track',lang('make_track')).']'?></p>
		<p><input type="button" class="gen_lp" name="_GEN" idlb="<?=$idlb?>" value="<?=lang('generate')?>" /><span id="loadLp_<?=$idlb?>"></span></p>
		<p><textarea name="hasil_gen" class="lp_code_area" id="code_<?=$idlb?>"></textarea></p>
	</div>
<? }}?>
</fieldset>

<script language="javascript">
$(function(){
	$('.lp_code_area').click(function(){
		$(this).select();
	});
	$('.gen_lp').click(function(){
		var idlb=$(this).attr('idlb');
		var trc=$('#trc_'+idlb).val();
		post_track='';
		if(trc!='' && trc!='-'){
			post_track='&trc='+trc
		}
			$.ajax({
				type: "POST",
				url: "<?=site_url($this->router->module.'/'.$this->router->class.'/'.$this->router->method.'/2')?>",
				data: "idbox="+idlb+"<?=$data_for_ajax?>"+post_track,
				beforeSend: function(){
					$('#loadLp_'+idlb).html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('#loadLp_'+idlb).html(msg.msg);
					$('#code_'+idlb).val(msg.script);
				},
				dataType: 'json'
			});
		//}else{
		//	alert('<?=lang('track_must_select')?>');
		//}
	});
});
</script>