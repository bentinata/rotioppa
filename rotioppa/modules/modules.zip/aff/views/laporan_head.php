<? 
for($t=1;$t<=date('t');$t++){$tgl[$t]=$t;}
for($b=1;$b<=12;$b++){$bln[$b]=$b;}
for($y=2010;$y<=date('Y');$y++){$year[$y]=$y;}
$lap=array('1'=>lang('this_weak'),'2'=>lang('this_month'),'3'=>lang('this_year'),);
?>

<fieldset class="boxq boxqbg2" style="width:600px">
	<legend><?=lang('view_lap')?></legend>
	<p>
		<input type="radio" class="tl" name="typelap" value="1" checked="true" />
		<?=lang('lihat_lap')?> <?=form_dropdown('lap',$lap)?>
	</p>
	<p>
		<input type="radio" class="tl" name="typelap" value="2" />
	<?=lang('lihat_tgl')?>
	<?=form_dropdown('tgl',$tgl,$this->input->post('tgl')?$this->input->post('tgl'):date('j'))?> 
	<?=form_dropdown('bln',$bln,$this->input->post('bln')?$this->input->post('bln'):date('n'))?> 
	<?=form_dropdown('thn',$year,$this->input->post('thn')?$this->input->post('thn'):date('Y'))?>
	<?=lang('until')?>
	<?=form_dropdown('tgl2',$tgl,$this->input->post('tgl2')?$this->input->post('tgl2'):date('j'))?> 
	<?=form_dropdown('bln2',$bln,$this->input->post('bln2')?$this->input->post('bln2'):date('n'))?> 
	<?=form_dropdown('thn2',$year,$this->input->post('thn2')?$this->input->post('thn2'):date('Y'))?>
	</p>
</fieldset>
