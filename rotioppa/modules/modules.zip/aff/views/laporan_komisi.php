<?
for($b=1;$b<=12;$b++){$bln[$b]=$b;}
for($y=2010;$y<=date('Y');$y++){$year[$y]=$y;}
?>
<?=$this->load->module_view(config_item('modulename'),'head_aff')?>
<h3><?=lang('lap_komisi')?></h3>
<br />
<fieldset class="boxq boxqbg2" style="width:500px">
	<legend><?=lang('komisi_anda')?></legend>
	<br /><p class="komisi_rupiah">Rp. <?=currency($komisi_anda)?>,00</p><br />
</fieldset>
<br />

<fieldset class="boxq boxqbg2" style="width:500px">
	<legend><?=lang('view_lap')?></legend>
	<p>
	<?=lang('lihat_bln')?>
	<?=form_dropdown('bln',$bln,$this->input->post('bln')?$this->input->post('bln'):date('n'))?> 
	<?=form_dropdown('thn',$year,$this->input->post('thn')?$this->input->post('thn'):date('Y'))?>
	<?=lang('until')?>
	<?=form_dropdown('bln2',$bln,$this->input->post('bln2')?$this->input->post('bln2'):date('n'))?> 
	<?=form_dropdown('thn2',$year,$this->input->post('thn2')?$this->input->post('thn2'):date('Y'))?>
	</p>
</fieldset>

<br />

<input id="doview" type="submit" name="_VIEW" value="<?=lang('view_lap')?>" />
<br />
<br />

<h2><?=lang('report_your_comm')?></h2><br />
<div id="viewIklan">
<? $this->template->load_view('laporan_komisi2',false,config_item('modulename'))?>
</div>

<span id="bigload" class="hide"><?=loadImg('big-loader.gif')?></span>
<script language="javascript">
$(function(){
	$("select[name='page']").val($('option:first', $("select[name='page']")).val());
	
	$('#doview').click(function(){
		t1=$("select[name='thn']").val()+'-'+$("select[name='bln']").val();
		t2=$("select[name='thn2']").val()+'-'+$("select[name='bln2']").val();
		tl='&dt1='+t1+'&dt2='+t2;

			$.ajax({
				type: "POST",
				url: "<?=site_url(config_item('modulename').'/'.$this->router->class.'/lapkom/1')?>",
				data: "start=1"+tl,
				beforeSend: function(){
					$('#viewIklan').html($('#bigload').html());
				},
				success: function(msg){ //alert(msg);
					$('#viewIklan').html(msg);
				}
			});
	});

});
</script>
