<h3>Aktivasi Affiliate</h3>
<br />
<br />
<? if(isset($ok)){?><div class="<?=$ok?'msg_success':'msg_error'?>"><?=$msg?></div><? }?>