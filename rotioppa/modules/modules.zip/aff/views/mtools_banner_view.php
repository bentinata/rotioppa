<?
$lb='javascript:void();';
if(isset($link_banner)) $lb=$link_banner;
?>
<a href="<?=$lb?>">
<?=loadImg(config_item('dir_banner').'/'.$img_banner,array('style'=>'border:none;'),FALSE,FALSE,TRUE)?>
</a>