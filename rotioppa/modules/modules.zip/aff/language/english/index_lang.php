<?php
$lang['mn_home'] = 'Home';
$lang['mn_aff'] = 'Affiliate';
$lang['mn_login'] = 'Login Affiliate';
$lang['mn_logout'] = 'Logout';
$lang['mn_member'] = 'Customer';

$lang['sub_lap_iklan'] = 'Laporan Iklan';
$lang['sub_lap_produk'] = 'Laporan Produk';
$lang['sub_lap_komisi'] = 'Laporan Komisi';
$lang['sub_mt_banner'] = 'Banner';
$lang['sub_mt_track'] = 'Tracking';
$lang['sub_mt_link'] = 'Link Produk';
$lang['sub_mt_created'] = 'Iklan yang telah dibuat';