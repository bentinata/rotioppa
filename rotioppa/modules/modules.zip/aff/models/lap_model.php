<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Lap_model extends CI_Model{
	var $tb_track,$tb_iklan,$tb_lapiklan,$tb_order,$tb_produk,$tb_sub,$tb_cekout,$tb_kom,$tb_kom_user;
	function __construct(){
		parent::__construct();
		$this->tb_track = 'track';
        $this->tb_iklan = 'iklan';
        $this->tb_lapiklan = 'laporan_iklan';
        $this->tb_order = 'order';
        $this->tb_produk = 'produk';
        $this->tb_sub = 'kategori_sub';
        $this->tb_cekout = 'cekout';
        $this->tb_kom = 'komisi';
        $this->tb_kom_user = 'komisi_user';
    }
    function list_track($idaff,$aktiv=1){
		$this->db->select("id,track");
        $this->db->where(array('id_aff'=>$idaff,'is_active'=>$aktiv));
		$query = $this->db->get($this->tb_track); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function list_iklan($search,$start=false,$limit=false,$justcount=false){
        $t=$this->tb_track;
        $i=$this->tb_iklan;
        $li=$this->tb_lapiklan;
        $lip=$this->db->dbprefix($li);

        if(!empty($search)){
            if(isset($search['track']))
            $this->db->where_in("$t.id",$search['track']);

            if(isset($search['aff']))
            $this->db->where("$i.id_aff",$search['aff']);

            if(isset($search['type'])){
                if($search['type']=='1'){
                    $this->db->where("$lip.tgl between '".format_date_fordb($search['range']['first'])."' and '".format_date_fordb($search['range']['last'])."'",FALSE,FALSE);
                }elseif($search['type']=='2')
                    $this->db->where("month($lip.tgl)=month(now())",FALSE,FALSE);
                elseif($search['type']=='3')
                    $this->db->where("year($lip.tgl)=year(now())",FALSE,FALSE);
            }
        }

        $this->db->join($i,"$i.id=$li.id_iklan",'left');
        $this->db->join($t,"$t.id=$i.id_track",'left');
		if($justcount){
			$this->db->select('count(*) as jml',FALSE);
			$query = $this->db->get("$li");
			$row = $query->row();
			return $row->jml;
		}
        // sementara jenis iklan di tulis manual karena masih blum jelas database nya
        $this->db->select("$i.id_banner,$li.tgl,$t.track,$li.impresi,$li.klik,$li.sales,jenis_iklan");
        #$this->db->select('1 as jenis_iklan',FALSE);
        $this->db->limit($limit,$start);
        $this->db->order_by("$li.tgl desc,$t.track");
        $query=$this->db->get("$li"); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function list_produk($search,$start=false,$limit=false,$justcount=false){ 
        $o=$this->tb_order;
        $t=$this->tb_track;
        $i=$this->tb_iklan;
        $s=$this->tb_sub;
        $p=$this->tb_produk;
        $op=$this->db->dbprefix($o);
        $ip=$this->db->dbprefix($i);
        $ck=$this->tb_cekout;

        if(!empty($search)){
            if(isset($search['track']))
            $this->db->where_in("$i.id_track",$search['track']);

            if(isset($search['aff']))
            $this->db->where("$i.id_aff",$search['aff']);

            if(isset($search['type'])){
                if($search['type']=='1'){
                    $this->db->where("date_format($op.tgl,'%Y-%m-%d') between '".format_date_fordb($search['range']['first'])."' and '".format_date_fordb($search['range']['last'])."'",FALSE,FALSE);
                }elseif($search['type']=='2')
                    $this->db->where("month($op.tgl)=month(now())",FALSE,FALSE);
                elseif($search['type']=='3')
                    $this->db->where("year($op.tgl)=year(now())",FALSE,FALSE);
            }
        }

        $this->db->join("$p","$p.id=$o.id_produk",'left');
        $this->db->join("$s","$s.id=$p.id_subkategori",'left');
        $this->db->join("$i","$i.id=$o.id_iklan",'left');
        $this->db->join("$t","$t.id=$i.id_track",'left');
        $this->db->join("$ck","$ck.id=$o.id_cekout",'left');
        $this->db->select("date_format($op.tgl,'%Y-%m-%d') as dt",FALSE);
        $this->db->group_by("$ip.id_track,dt,$op.id_produk");
        $this->db->where("status_bayar",status_bayar(true));
        $this->db->having("sum($op.komisi)!=0");

		if($justcount){
			$this->db->select('count(*) as jml');
			$query = $this->db->get("$o"); #echo $this->db->last_query();
            if($query->num_rows>0){
                return $query->num_rows();
            }
            return 0;
		}

        $this->db->select("$t.track,$s.subkategori,$p.nama_produk,sum($op.qty) as jml,sum($op.qty*$op.harga) as harga,sum($op.komisi) as kom");
        $this->db->limit($limit,$start);
        $this->db->order_by("$o.tgl desc,$t.track,$p.nama_produk");
        $query=$this->db->get("$o"); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    /*function list_komisi($search,$start=false,$limit=false,$justcount=false){
        $k=$this->tb_kom;

        $this->db->where("id_aff",$search['aff']);
        $this->db->where("date_format(tgl,'%Y-%m') between '".format_date_fordb($search['range']['first'])."' and '".format_date_fordb($search['range']['last'])."'",FALSE,FALSE);

		if($justcount){
			$this->db->select('count(*) as jml');
			$query = $this->db->get("$k"); #echo $this->db->last_query();
            if($query->num_rows>0){
                $row = $query->row();
			    return $row->jml;
            }
            return 0;
		}

        $this->db->select("date_format(tgl,'%Y-%m') as tgl,total_item,total_harga,total_komisi,status_kirim",FALSE);
        $this->db->limit($limit,$start);
        $this->db->order_by("tgl desc");
        $query=$this->db->get("$k"); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }*/
    function list_komisi($search,$start=false,$limit=false,$justcount=false){
        $k=$this->tb_kom;

        $this->db->where("id_aff",$search['aff']);
        $this->db->where("date_format(tgl,'%Y-%m') between '".format_date_fordb($search['range']['first'])."' and '".format_date_fordb($search['range']['last'])."'",FALSE,FALSE);

		if($justcount){
			$this->db->select('count(*) as jml');
			$query = $this->db->get("$k"); #echo $this->db->last_query();
            if($query->num_rows>0){
                $row = $query->row();
			    return $row->jml;
            }
            return 0;
		}

        $this->db->select("tgl,komisi");
        $this->db->limit($limit,$start);
        $this->db->order_by("tgl desc");
        $query=$this->db->get("$k"); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function komisi_anda($idaff){
        $k=$this->tb_kom_user;
        $this->db->where("id_aff",$idaff);
        $this->db->select("komisi");
        $query=$this->db->get("$k"); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->row();
			$query->free_result();
			return $row->komisi;
		} #break;
		return 0;
		
	}
}
