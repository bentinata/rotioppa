<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Global_model extends CI_Model{
	var $tb_track,$tb_kat,$tb_subkat;
	function __construct(){
		parent::__construct();
		$this->tb_track = 'track';
		$this->tb_kat = 'kategori';
		$this->tb_subkat = 'kategori_sub';
    }
    function option_track($empty=false,$idaff=false,$isactive=false){
		if($isactive)
		$this->db->where('is_active','1');
	
        $this->db->where('id_aff',$idaff);
        $this->db->order_by('track');
		$query = $this->db->get($this->tb_track);
		if($query->num_rows()>0){ #break;
			if($empty) $res['-'] = ' - ';
			foreach($query->result() as $row){
				$res[$row->id] = $row->track;
			}
			$query->free_result();
			return $res;
		} #break;
		return false;
    }
	function option_kat($empty=true){
		$this->db->order_by('kategori');
		$query = $this->db->get($this->tb_kat); #echo $this->db->last_query();
		
		if($query->num_rows()>0){ #break;
			if($empty) $data[''] = ' - ';
			foreach($query->result() as $row){
				$data[$row->id] = $row->kategori;
			}
			$query->free_result();
			return $data;
		} #break;
		return false;
	}
	function option_subkat($idkat,$empty=true){
		$this->db->order_by('subkategori');
		$this->db->where('id_kategori',$idkat);
		$query = $this->db->get($this->tb_subkat); #echo $this->db->last_query();
		
		if($query->num_rows()>0){ #break;
			if($empty) $data[''] = ' - ';
			foreach($query->result() as $row){
				$data[$row->id] = $row->subkategori;
			}
			$query->free_result();
			return $data;
		} #break;
		return false;
	}
}
