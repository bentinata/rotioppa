<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mtools_model extends CI_Model{
	var $tb_track,$tb_iklan,$tb_produk,$tb_gbr,$tb_subkat,$tb_diklan;
	function __construct(){
		parent::__construct();
		$this->tb_track = 'track';
        $this->tb_iklan = 'iklan';
        $this->tb_produk= 'produk';
        $this->tb_gbr='gambar';
        $this->tb_subkat='kategori_sub';
        $this->tb_diklan='iklan_data';
    }
    function option_track($empty=false,$idaff=false,$isactive=false)
    {
		if($isactive)
		$this->db->where('is_active','1');
		
        $this->db->where('id_aff',$idaff);
        $this->db->order_by('track');
		$query = $this->db->get($this->tb_track);
		if($query->num_rows()>0){ #break;
			if($empty) $res['-'] = ' - ';
			foreach($query->result() as $row){
				$res[$row->id] = $row->track;
			}
			$query->free_result();
			return $res;
		} #break;
		return false;
    }

    function list_track($idaff,$start=false,$limit=false,$justcount=false){
		$this->db->select("id,track,is_active");
        $this->db->where(array('id_aff'=>$idaff));

		if($justcount){
			$this->db->select('count(*) as jml',FALSE);
			$query = $this->db->get($this->tb_track);
			$row = $query->row();
			return $row->jml;
		}
        $this->db->limit($limit,$start);
        $this->db->order_by('track');
		$query = $this->db->get($this->tb_track); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function add_track($aff,$status,$track=false){
        $data = array('is_active'=>$status,'track'=>$track,'id_aff'=>$aff);
        $this->db->insert($this->tb_track,$data);#echo $this->db->last_query();
        return $this->db->insert_id();
    }
    function update_track($aff,$id,$status,$track=false){
        $this->db->where(array('id_aff'=>$aff,'id'=>$id));
        $this->db->set(array('is_active'=>$status));
        if($track)
        $this->db->set(array('track'=>$track));
        return $this->db->update($this->tb_track);
    }
    function detail_track($aff,$id){
        $this->db->where(array('id_aff'=>$aff,'id'=>$id));
		$query = $this->db->get($this->tb_track); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->row();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function dell_track($aff,$id){
        
    }
    function has_create_iklan($banner,$id_aff,$track=false,$jenis=1){
        $this->db->select('id');
        if($track) $this->db->where(array('id_track'=>$track));
        else $this->db->where(array('id_aff'=>$id_aff,'id_track'=>'0'));
        
        $this->db->where(array('id_banner'=>$banner,'jenis_iklan'=>$jenis));
        $query = $this->db->get($this->tb_iklan); #echo $this->db->last_query();
		if($query->num_rows()>0){
			$row = $query->row();
			$query->free_result();
 			return $row->id;
		}
		return false;
    }
    function create_iklan($banner,$id_aff,$track=false,$jenis=1){
        $data = array('id_aff'=>$id_aff,'id_banner'=>$banner,'jenis_iklan'=>$jenis,'id_track'=>$track);
        $this->db->insert($this->tb_iklan,$data);
        return $this->db->insert_id();
    }
    function get_produk_for_linkproduk($search){
		$p=$this->tb_produk;
		$g=$this->tb_gbr;
		$sk=$this->tb_subkat;
		$gp=$this->db->dbprefix($g);
		$dosql=false;
        if(!empty($search['key'])){ $dosql=true;
			$this->db->like('nama_produk',$search['key']);
		}
		if(!empty($search['kat'])){ $dosql=true;
			$this->db->where('id_kategori',$search['kat']);
		}
		if(!empty($search['subkat'])){ $dosql=true;
			$this->db->where('id_subkategori',$search['subkat']);
		}
		if($dosql){ // jika ada salah satu kriteria where
		$this->db->select("$p.id,gambar,$g.id as idgbr,nama_produk");
		$this->db->select("$p.harga_awal_diskon AS ha_diskon,$p.harga_baru_diskon AS hb_diskon,"
						 ."$p.harga_awal AS ha_prop,$p.harga_baru AS hb_prop",FALSE);
		$this->db->join($g,"$g.id_produk=$p.id and $gp.is_default='1'",'left');
		$this->db->join($sk,"$sk.id=$p.id_subkategori");
        $this->db->limit(10); // sementara hanya di tampilkan 10 produk saja
        $this->db->order_by('rand()');
		$query = $this->db->get($p); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		} // dosql
		return false;
    }
    function add_data_iklan($idiklan,$data){
		$input=array('id_iklan'=>$idiklan,'data'=>$data);
		return $this->db->insert($this->tb_diklan,$input);
	}
    function update_data_iklan($idiklan,$data){
		$update=array('data'=>$data);
		$this->db->where('id_iklan',$idiklan);
		return $this->db->update($this->tb_diklan,$update);
	}
	function get_data_iklan_by_idiklan($idiklan){
		$query=$this->db->get_where($this->tb_diklan,array('id_iklan'=>$idiklan));
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		}
		return false;
	}
}
