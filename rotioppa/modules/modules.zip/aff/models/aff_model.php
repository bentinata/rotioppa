<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Aff_model extends CI_Model{
	var $tb_aff,$tb_info,$tb_faq;
	function __construct(){
		parent::__construct();
		$this->tb_aff = 'aff';
        $this->tb_info = 'info';
        $this->tb_faq = 'faq';
    }
    function detail_aff($id){
        $f=$this->tb_aff;
        $query = $this->db->get_where($this->tb_aff,array('id'=>$id)); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->row();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function detail_aff_bymail($mail){
        $f=$this->tb_aff;
        $query = $this->db->get_where($this->tb_aff,array('email'=>$mail)); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->row();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function update_aff($id,$pass,$full,$nick,$tlp,$hp,$jenkel,$lahir,$alamat,$kota,$prov,$negara,$pay,$kom){
        $set=array(
            'password'=>$pass,
            'nama_lengkap'=>$full,
            'nama_panggilan'=>$nick,
            'no_tlp'=>$tlp,
            'no_hp'=>$hp,
            'jen_kel'=>$jenkel,
            'tgl_lahir'=>$lahir,
            'alamat'=>$alamat,
            'kota'=>$kota,
            'provinsi'=>$prov,
            'negara'=>$negara,
            'pay_method'=>$pay,
            'min_transfer'=>$kom
        );
        $this->db->where('id',$id);
        return $this->db->update($this->tb_aff,$set);
    }
    function reg_aff($email,$pass,$full,$nick,$tlp,$hp,$jenkel,$lahir,$alamat,$kota,$prov,$negara,$pay='1',$kom,$code,$web,$status='2'){
        $set=array(
            'email'=>$email,
            'password'=>$pass,
            'nama_lengkap'=>$full,
            'nama_panggilan'=>$nick,
            'no_tlp'=>$tlp,
            'no_hp'=>$hp,
            'jen_kel'=>$jenkel,
            'tgl_lahir'=>$lahir,
            'tgl_daftar'=>date('Y-m-d H:i:s'),
            'alamat'=>$alamat,
            'kota'=>$kota,
            'provinsi'=>$prov,
            'negara'=>$negara,
            'pay_method'=>$pay,
            'min_transfer'=>$kom,
            'activation_code'=>$code,
            'urlweb'=>$web,
            'status'=>$status
        );
        return $this->db->insert($this->tb_aff,$set);
    }
    function get_info(){
        $this->db->select('info');
        $this->db->where(array('is_view'=>'1','id_level'=>'2'));
        $this->db->order_by("tgl desc");
        $query = $this->db->get($this->tb_info); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
    function get_faq(){
        $this->db->select('question,answer');
        $this->db->where(array('is_view'=>'1','id_level'=>'2'));
        $this->db->order_by("tgl desc");
        $query = $this->db->get($this->tb_faq); #echo $this->db->last_query();
		if($query->num_rows()>0){ #break;
			$row = $query->result();
			$query->free_result();
			return $row;
		} #break;
		return false;
    }
	function active_aff($code,$email){
		$this->db->where(array('activation_code'=>$code,'email'=>$email));
		$this->db->set(array('status'=>'1'));
		return $this->db->update($this->tb_aff);
	}
}
