<div class="header">
	<?=loadImgThem('icon/mainmenu.png','',false,config_item('modulename'),true)?>
	<span><?=lang('main_menu')?></span>
</div>

<div id="box-home">
<div id="cpanel">
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/produk')?>">
			<?=loadImgThem('icon/big-produk.png','',false,config_item('modulename'),true)?>					
			<span>Produk</span></a>
		</div>
	</div>
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/produk/input')?>">
			<?=loadImgThem('icon/big-produk-input.png','',false,config_item('modulename'),true)?>					
			<span>Input Produk</span></a>
		</div>
	</div>
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/katalog')?>">
			<?=loadImgThem('icon/katalog.png','',false,config_item('modulename'),true)?>					
			<span>Katalog</span></a>
		</div>
	</div>
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/kategori')?>">
			<?=loadImgThem('icon/big-kategori.png','',false,config_item('modulename'),true)?>					
			<span>Kategori</span></a>
		</div>
	</div>
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/kategori/input')?>">
			<?=loadImgThem('icon/big-kategori-input.png','',false,config_item('modulename'),true)?>					
			<span>Input Kategori</span></a>
		</div>
	</div>
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/kategori/sub')?>">
			<?=loadImgThem('icon/big-subkat.png','',false,config_item('modulename'),true)?>					
			<span>Sub Kategori</span></a>
		</div>
	</div>
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/kategori/subinput')?>">
			<?=loadImgThem('icon/big-subkat-input.png','',false,config_item('modulename'),true)?>					
			<span>Input Sub Kategori</span></a>
		</div>
	</div>
	<div style="float: left;">
		<div class="icon">
			<a href="<?=site_url(config_item('modulename').'/biayakirim')?>">
			<?=loadImgThem('icon/big-biaya.png','',false,config_item('modulename'),true)?>					
			<span>Biaya Kirim</span></a>
		</div>
	</div>
</div>
<br style="clear:both" />
</div>