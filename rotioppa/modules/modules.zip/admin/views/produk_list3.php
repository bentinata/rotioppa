<? if($list_produk){$i=$startnumber;foreach($list_produk as $lk){$i++;?>
<tr class="<?=($i%2)==1?'row0':'row1'?>">
	<td><?=$i?></td>
	<td><?=$lk->vcode?></td>
	<td><?=format_kode($lk->idkat).format_kode($lk->idsub,3).$lk->id?></td>
	<td><?=$lk->nama_produk?></td>
	<td><?=$lk->kategori?></td>
	<td><?=$lk->subkategori?></td>
	<td><?=$lk->subkategori2?></td>
    <td><?=$lk->katalog?></td>
	<td><? $dt=explode(' ',$lk->tgl);echo format_date_ina($dt[0],'-',' ')?></td>
	<td>
	<?=anchor($this->module.'/'.$this->router->class.'/edit/'.$lk->id,loadImgThem('icon/edit.png','',false,config_item('modulename'),true),array('title'=>lang('edit')))?>
	<?=anchor($this->module.'/'.$this->router->class.'/delete/'.$lk->id,loadImgThem('icon/delete.png','',false,config_item('modulename'),true),array('title'=>lang('del'),'class'=>'butdelproduk'))?>
	</td>
</tr>
<? }}?>

<script language="javascript">
$(function(){
	$('.butdelproduk').click(function(){ 
		if(confirm("<?=lang('sure_dell_produk')?>")){
			return true;
		}
		return false;
	});
});
</script>