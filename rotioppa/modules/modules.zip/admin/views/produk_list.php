<?
$arr_filter = array(
	'0'=>' - ',
	'1'=>lang('k_produk'),
	'2'=>lang('n_produk'),
	'3'=>lang('kat'),
	//'4'=>lang('subkat'),
	'5'=>lang('tgl_in'),
	'6'=>lang('stock'),
	'7'=>lang('vendor')
	);
$vd='';
$ivd='';
if(isset($vcode_detail) && $vcode_detail){
	$vd = '( '.$vcode_detail->kode_produk_vendor.' )';
	$ivd= '/'.$vcode_detail->id;
}
?>
<div class="header">
	<?=loadImgThem('icon/mainmenu.png','',false,config_item('modulename'),true)?>
	<span><?=lang('list_produk').' '.$vd?></span>
</div>
<br class="clr" />

<div class="cari left">
	<b><?=lang('filter_by')?></b> <?=form_dropdown('filter',$arr_filter,7) // default nya no 7 (vendor) karena ada masalah yg aneh?> 
	<span class="hd hide key"><input type="text" class="in_search" name="search" />&nbsp;</span>
	<span class="hd hide tgl">
			<?=loadCss('js/calendar/theme/redmond/ui.all.css',false,true,false,true)?>
			<?=loadJs('calendar/ui/ui.core.js',false,true)?>
			<?=loadJs('calendar/ui/ui.datepicker.js',false,true)?>
			<?=loadJs('calendar/ui/ui.datepicker-id.js',false,true)?>
			<script type="text/javascript">
				$(function() {
					$("#dp_tgl").datepicker({
						showOn: "button",
						buttonImage: "<?=loadImg('js/calendar/calendar.gif','',true,false,true,true)?>",
						changeMonth: true,changeYear: true,
						buttonImageOnly: true,
						dateFormat: "dd MM yy",
						altField: '#tgl_hide', 
						altFormat: 'yy-mm-dd'
					}).attr("disabled", true);
				});	</script>
			<style>.ui-datepicker {font-size:10px;}	</style>
			<input type="text" name="tgl" id="dp_tgl" /> 
			<input type="hidden" id="tgl_hide" name="tgl_key" />
			&nbsp;
			<script type="text/javascript">
				$(function() {
					$("#dp_tgl2").datepicker({
						showOn: "button",
						buttonImage: "<?=loadImg('js/calendar/calendar.gif','',true,false,true,true)?>",
						changeMonth: true,changeYear: true,
						buttonImageOnly: true,
						dateFormat: "dd MM yy",
						altField: '#tgl2_hide', 
						altFormat: 'yy-mm-dd'
					}).attr("disabled", true);
				});	</script>
			<style>.ui-datepicker {font-size:10px;}	</style>
			<input type="text" name="tgl2" id="dp_tgl2" /> 
			<input type="hidden" id="tgl2_hide" name="tgl2_key" />&nbsp;
			<?=form_dropdown('order',array('desc'=>'Terbaru','asc'=>'Terlama'))?>
	</span>
	<span class="hd hide kat">
		<?=form_dropdown('kat',$kat)?>
		<select name="subkat"><option> - </option></select>
		<span id="load_subkat"></span>
	</span>
	<span class="hd vendor">
		<?=form_dropdown('vendor',$vendor)?>
		<select name="vcode"><option> - </option></select>
		<span id="load_vcode"></span>
		<input type="text" name="q" id="query" />
	</span>
	<input type="submit" name="_SEARCH" value="<?=lang('search')?>" />
	<span class="load1"></span>
</div>
<div class="hide left msg_success" id="msg_search"></div>
<div class="hide left msg_error" id="msg_search2"></div>
<br class="clr" /><br />

<span class="load2"></span>
<div id="viewajax1">
<? $this->template->load_view('produk_list2',false,config_item('modulename'))?>
</div>

<span id="bigload" class="hide"><?=loadImgThem('ajax-loader-big.gif','',false,config_item('modulename'),true)?></span>
<span id="smalload" class="hide"><?=loadImgThem('ajax-loader.gif','',false,config_item('modulename'),true)?></span>

<!-- autocomplete -->
<?=loadJs('autocomplete/jquery.autocomplete.js',false,true)?>
<?=loadCss('js/autocomplete/styles.css',false,true,false,true)?>

<script language="javascript">
$(function(){
	$("select[name='kat']").val($('option:first', $("select[name='kat']")).val());
	$("select[name='vendor']").val($('option:first', $("select[name='vendor']")).val());
	$("select[name='filter']").val(7)
	.change(function(){
		$('.hd').hide();
		if($(this).val()=='5'){ 
			$('.tgl').show();
		}else if($(this).val()=='3'){ 
			$('.kat').show();
		}else if($(this).val()=='7'){ 
			$('.vendor').show();
		}else{ 
			$('.key').show();
		}
	});

	$("select[name='kat']").change(function(event,kt){
		if(kt) thisval=kt;
		else thisval = $(this).val();
		if(thisval!='-'){
			$.ajax({
				type: "POST",
				url: "<?=site_url(config_item('modulename').'/'.$this->router->class.'/optionsubkat')?>",
				data: "kat="+thisval,
				beforeSend: function(){
					$("select[name='subkat']").hide();
					$('#load_subkat').html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('#load_subkat').html('');
					$("select[name='subkat']").html(msg).show();
				}
			});
		}
	});
	$("select[name='vendor']").change(function(event,kt){
		if(kt) thisval=kt;
		else thisval = $(this).val();
		if(thisval!='-'){
			$.ajax({
				type: "POST",
				url: "<?=site_url(config_item('modulename').'/'.$this->router->class.'/optionvcode')?>",
				data: "vendor="+thisval,
				beforeSend: function(){
					$("select[name='vcode']").hide();
					$('#load_vcode').html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('#load_vcode').html('');
					$("select[name='vcode']").html(msg.res).show();
					a2.setOptions({ lookup: msg.val.split(',') });
				},
				dataType:'json'
			});
		}
	});
	// input and keep selected
	var a2 = $('#query').autocomplete({
		lookup: '',
		onSelect: function (value, data){ 
			$("select[name='vcode'] option:contains("+value+")").attr("selected", true);
			var ids=$("select[name='vcode'] option:contains("+value+")").val();
			$("select[name='vcode']").trigger('change',[ids]);
		}
	});
	
	$("input[name='_SEARCH']").click(function(){
		fi=$("select[name='filter']").val();
		nxt=false;
		vars='';
		if(fi=='5'){
			t1=$("#tgl_hide").val();
			t2=$("#tgl2_hide").val();
			ords=$("select[name='order']").val();
			if(t1!='' && t2!=''){ 
				nxt=true;
				vars='&tgl1='+t1+'&tgl2='+t2+'&ord='+ords;
			}
		}else if(fi=='3'){
			ky=$("select[name='subkat']").val();
			if(ky!='-'){ 
				nxt=true;
				vars='&search='+ky;
			}
		}else if(fi=='7'){
			ky=$("select[name='vcode']").val();
			if(ky!='-'){ 
				nxt=true;
				vars='&search='+ky;
			}
		}else{
			ky=$("input[name='search']").val();
			if(ky!=''){ 
				nxt=true;
				vars='&search='+ky;
			}
		}
		if(nxt && fi!='0'){
			$.ajax({
				type: "POST",
				url: "<?=site_url(config_item('modulename').'/'.$this->router->class.'/'.$this->router->method.'/1'.$ivd)?>",
				data: "filter="+fi+vars,
				beforeSend: function(){
					$('#msg_search').hide();
					$('#msg_search2').hide();
					$('#viewajax1').hide();
					$('.load2').html($('#bigload').html());
					$('.load1').html($('#smalload').html());
				},
				success: function(msg){ //alert(msg);
					$('.load1').html('');
					$('.load2').html('');
					if(msg.err!=''){ 
						$('#msg_search2').html(msg.err).fadeIn();
						$('#viewajax1').fadeIn();
					}else{
						$('#msg_search').html(msg.msg).fadeIn();
						$('#viewajax1').html(msg.view).fadeIn();
					}
				},
				dataType: "json"
			});
		}else
			alert('<?=lang('keyword_must_fill')?>');
	});

});
</script>
