<? if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends Admin_Controller{
	function __construct()
	{
		parent::__construct(); 
		/* load lang */
		#$this->lang->load('poseidon',$this->globals->lang);
		/* load model */
		#$this->load->module_model('login', 'login_model', 'lm');

		/* header description 
		$data['title'] 			= config_item('site_title_pos');
		$data['keyword'] 		= config_item('site_keyword_pos');
		$data['description'] 	= config_item('site_desc_pos');
		$this->template->set($data); 
		*/
	}
	function index()
	{
		$this->lang->load('home');
		$this->template->set_view ('home',false,config_item('modulename'));
	}
	
    function create_page($page='about'){
        $folder = config_item('dir_upload').'/page/';
        $data['page'] = $page;
        $this->load->helper('file');
        switch($page){
            default:
                $file='about.txt';
                break;
            case'mitra':
                $file='mitra.txt';
                break;
            case'contact':
                $file='contact.txt';
                break;
        }
        
        if($this->input->post('_INPUT'))
        {
            write_file($folder.$file,$this->input->post('page'));
            $data['ok'] = 'Input Success!';
        }
        
        $data['read'] = read_file($folder.$file);
        $this->template->set_view('create_page',$data);
    }
    
	function test_excel()
	{
		// load library
		$this->load->library('PHPExcel');
		$this->load->library('PHPExcel/IOFactory');
		$objPHPExcel = new PHPExcel();
		
		// properties of document
		$objPHPExcel->getProperties()
				->setTitle("title sample")
				->setDescription("description sample")
				->setCreator('Creator')
                ->setLastModifiedBy('Modifier');
        
        // sample data
        $test = array(
                0 => array(
                        'a' => 'åäö',
                        'b' => 'æåø',
                        'c' => '123',
                        'e' => 'abfaeagkae'
                        ),
                1 => array(
                        'a' => 'åäö',
                        'b' => 'æåø',
                        'c' => '123',
                        'e' => 'abfaeagkae'
                        )
            );
        
        // metode penulisan sheet    
        $objPHPExcel->setActiveSheetIndex(0);
        $sheet=$objPHPExcel->getActiveSheet();
		$sheet->SetCellValue('A1', 'Hello how are u today? i\' not sure about that :)');
		$sheet->SetCellValue('A3', 'Hello how are u today? i\' not sure about that :)');
		$sheet->SetCellValue('B2', '05-06-2011 09:36:02');
		$sheet->SetCellValue('C2', '0032 ');
		$sheet->SetCellValue('D2', '879 ');

$objPHPExcel->getActiveSheet()->getCell('A10')->setValue(199);
$objPHPExcel->getActiveSheet()->getStyle('A10')->getNumberFormat()
->setFormatCode('0000');

// write integer
$objPHPExcel->getActiveSheet()->setCellValue('A11', 10);

// MySQL-like timestamp '2008-12-31'
Cell::setValueBinder( new Cell_AdvancedValueBinder() );
$objPHPExcel->getActiveSheet()->setCellValue('D10', '2008-12-31 13:03:05');
$objPHPExcel->getActiveSheet()->getStyle('D10')->getNumberFormat()
->setFormatCode(Style_NumberFormat::FORMAT_DATE_DATETIME);


$objPHPExcel->getActiveSheet()->getDefaultStyle()->getFont()->setSize(8);

$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16)->setBold(true);
$objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(30);

$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(16)->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setVertical(Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getRowDimension('3')->setRowHeight(30);
$objPHPExcel->getActiveSheet()->mergeCells('A3:F3');

$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);


$objPHPExcel->getActiveSheet()->getStyle('B2')->getFont()->getColor()->setARGB(Style_Color::COLOR_RED);

#$objPHPExcel->getActiveSheet()->getStyle('B2')->getAlignment()->setHorizontal(Style_Alignment::HORIZONTAL_RIGHT);

$objPHPExcel->getActiveSheet()->getStyle('B2')->getBorders()->getTop()->setBorderStyle(Style_Border::BORDER_THIN);
#->getColor()->setARGB(Style_Color::COLOR_RED);
#->getColor()->setRGB('cccccc');

$objPHPExcel->getActiveSheet()->getStyle('B2')->getBorders()->getBottom()->setBorderStyle(Style_Border::BORDER_THICK);
$objPHPExcel->getActiveSheet()->getStyle('B2')->getBorders()->getLeft()->setBorderStyle(Style_Border::BORDER_HAIR);
$objPHPExcel->getActiveSheet()->getStyle('B2')->getBorders()->getRight()->setBorderStyle(Style_Border::BORDER_MEDIUM);

$objPHPExcel->getActiveSheet()->getStyle('B2')->getFill()->setFillType(Style_Fill::FILL_SOLID)
->getStartColor()->setRGB('cccccc');

		/*$cell = 'A';
		$headings = array_keys($test);
		foreach($headings as $heading)
		{
			$sheet->setCellValue(($cell++) . '1', $heading);
		}
                    
		$row_num = 1;
		foreach($test as &$row)
		{
			$cell = 'A';
			++$row_num;

			#print_r($row);

			foreach($row as $value)
			{
				$sheet->setCellValue(($cell++) . $row_num, $value);
			}
		}*/

		// buat sheet baru
		#$objPHPExcel->createSheet();
		
		// aktifkan dan tulis di sheet baru
        #$objPHPExcel->setActiveSheetIndex(1);
        #$objPHPExcel->getActiveSheet()->setCellValue("A1", "åöä value here 222");
        
        // header   
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="sample.xls"');
		header('Cache-Control: max-age=0');
		
		// nama file
		$objWriter = IOFactory::createWriter($objPHPExcel, 'Excel5');
		$objWriter->save('php://output'); 
	}
    function update_pass()
    {
        $data = false;
        if($this->input->post('_CHANGE_PASS'))
        {
            $this->load->model('info_model','mod');
            
            $oldpass = trim($this->input->post('oldpass'));
            $newpass = trim($this->input->post('newpass'));
            $confpass = trim($this->input->post('confpass'));
                        
            $q = $this->mod->db->get_where('poseidonuser',array('username'=>$this->login_lib->pos_get_data('username'),'password'=>$oldpass));
            if($q->num_rows()>0)
            {
                if($newpass==$confpass){
                    $this->mod->db->update('poseidonuser',array('password'=>$newpass));
                    $data['ok'] = '1';
                    $data['msg'] = 'Edit berhasil';
                }else
                    $data['msg'] = 'Confirmasi password tidak sama';
            }else
                $data['msg'] = 'Password lama salah';
        }
        $this->template->set_view('password',$data);
    }
}
