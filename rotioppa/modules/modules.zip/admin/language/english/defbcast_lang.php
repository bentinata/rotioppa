<?php
$lang['bcast'] = 'Broadcast';
$lang['mail'] = 'Email';
$lang['antrian'] = 'Antrian';
$lang['terkirim'] = 'Terkirim';
$lang['gagal'] = 'Gagal';
$lang['make_bcast'] = 'Buat Broadcast';
$lang['edit_bcast'] = 'Edit Broadcast';

$lang['to'] = 'To';
$lang['subject'] = 'Subject';
$lang['sure_dell_mail'] = 'Yakin email broadcast akan dihapus?';
$lang['sure_stop_mail'] = 'Yakin email broadcast akan distop?';

$lang['proses_1'] = 'Progres...';
$lang['proses_2'] = 'Stop';
$lang['proses_3'] = 'Selesai';

$lang['proses_now'] = 'Proses email';
$lang['stop_now'] = 'Stop email';

$lang['stop_ok'] = 'Email telah distop.';
$lang['stop_er'] = 'Gagal distop.';
$lang['proses_ok'] = 'Email sedang diproses';
$lang['proses_er'] = 'Email gagal diproses';