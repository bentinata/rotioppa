<?php
$lang['list_info'] = 'List Informasi Member';
$lang['info'] = 'Informasi';
$lang['input_info'] = 'Input Informasi';
$lang['edit_info'] = 'Edit Informasi';
$lang['det_info'] = 'Detail Informasi';
$lang['no'] = 'No.';

$lang['list_faq'] = 'List FAQ';
$lang['tanya'] = 'Pertanyaan';
$lang['jawab'] = 'Jawaban';
$lang['input_faq'] = 'Input FAQ';
$lang['edit_faq'] = 'Edit FAQ';
$lang['det_faq'] = 'Detail FAQ';

$lang['sure_dell_info'] = 'Yakin akan dihapus?';
