<?php
$lang['main_menu'] = 'Menu Utama';