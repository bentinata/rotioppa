<?php
$lang['dl_center_excel'] = 'Download data excel';
$lang['tgl'] = 'Tgl.';
$lang['sd_tgl'] = 'Sampai tgl.';
$lang['no_data'] = 'Tidak ada data';
$lang['download'] = 'Dowload sekarang!';
$lang['set_tgl'] = 'Set tanggal terlebih dahulu!';

$lang['dl_member'] = 'Download data member ( tgl Signup )';
$lang['dl_produk'] = 'Download data produk ( tgl Input )';
$lang['dl_prospek'] = 'Download data prospek ( tgl Signup )';
$lang['dl_transaksi'] = 'Download data transaksi ( tgl Cekout )';
$lang['dl_aff'] = 'Download data affiliate ( tgl Daftar )';
$lang['dl_kom'] = 'Download data komisi ( bulanan )';
$lang['dl_untung'] = 'Download data produk terjual ( bulanan )';