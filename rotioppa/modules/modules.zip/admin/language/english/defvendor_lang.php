<?php
$lang['list_vendor'] = 'Daftar Vendor';
$lang['no'] = 'No.';
$lang['vendor'] = 'Vendor';
$lang['vcode'] = 'Kode Vendor';
$lang['det_vendor'] = 'Detail Vendor';
$lang['edit_vendor'] = 'Edit Vendor';
$lang['input_vendor'] = 'Input Vendor';
$lang['det_vcode'] = 'Detail Kode Vendor';
$lang['edit_vcode'] = 'Edit Kode Vendor';
$lang['input_vcode'] = 'Input Kode Vendor';
$lang['back'] = 'Kembali';

$lang['sure_dell_vendor'] = 'Yakin akan dihapus? \r\nHarap diperhatikan, jumlah kode vendor harus 0.';
$lang['sure_dell_vcode'] = 'Yakin akan dihapus? \r\nHarap diperhatikan, jumlah Produk harus 0.';
$lang['no_data'] = 'Tidak ada data.';
$lang['kat_must_fill'] = 'Vendor harus diisi!';
$lang['subkat_must_fill'] = 'Vendor dan Kode Vendor harus diisi!';

$lang['list_vcode'] = 'Daftar Kode Vendor';
$lang['produk'] = 'Produk';
$lang['vcode_has_input'] = 'Kode produk vendor sudah ada di database!';