<?php
$lang['list_artikel'] = 'List Artikel';
$lang['artikel'] = 'Artikel';
$lang['input_info'] = 'Input Artikel';
$lang['edit_info'] = 'Edit Artikel';
$lang['det_info'] = 'Detail Artikel';
$lang['no'] = 'No.';
$lang['summary'] = 'Summary';
$lang['content'] = 'Content';
$lang['title'] = 'Title';
$lang['sure_dell_artikel'] = 'Yakin akan dihapus?';
