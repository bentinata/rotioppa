<?php
$lang['list_wish'] = 'Daftar WishList';
$lang['no'] = 'No.';
$lang['nama'] = 'Nama';
$lang['email'] = 'Email';
$lang['produk'] = 'Nama Produk';
$lang['tgl_add'] = 'Tgl. Input';
$lang['produk_detail'] = 'Detail Produk';

$lang['sure_dell_wish'] = 'Yakin akan dihapus?';

