<?php
$lang['select_option'] = '-- select --';
$lang['list_kat'] = 'Daftar Katalog';
$lang['no'] = 'No.';
$lang['kode'] = 'Kode';
$lang['kat'] = 'Katalog';
$lang['det_kat'] = 'Detail Katalog';
$lang['edit_kat'] = 'Edit Katalog';
$lang['input_kat'] = 'Input Katalog';
$lang['back'] = 'Kembali';

$lang['sure_dell_kat'] = 'Yakin akan dihapus? \r\nHarap diperhatikan, jumlah SubKatalog harus 0.';
$lang['no_data'] = 'Tidak ada data.';
$lang['kat_must_fill'] = 'Katalog harus diisi!';
$lang['form_complete'] = 'Lengkapi form tersebut!';
$lang['produk'] = 'Produk';

