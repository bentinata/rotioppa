<?php
$lang['select_option'] = '-- select --';
$lang['list_kat'] = 'Daftar Kategori';
$lang['no'] = 'No.';
$lang['kode'] = 'Kode';
$lang['kat'] = 'Kategori';
$lang['subkat'] = 'Subkategori';
$lang['det_kat'] = 'Detail Kategori';
$lang['edit_kat'] = 'Edit Kategori';
$lang['input_kat'] = 'Input Kategori';
$lang['det_subkat'] = 'Detail Subkategori';
$lang['edit_subkat'] = 'Edit Subkategori';
$lang['input_subkat'] = 'Input Subkategori';
$lang['back'] = 'Kembali';

$lang['sure_dell_kat'] = 'Yakin akan dihapus? \r\nHarap diperhatikan, jumlah Subkategori harus 0.';
$lang['sure_dell_subkat'] = 'Yakin akan dihapus? \r\nHarap diperhatikan, jumlah Produk harus 0.';
$lang['sure_dell_subkat2'] = 'Yakin akan dihapus? \r\nHarap diperhatikan, jumlah Produk harus 0.';	
$lang['no_data'] = 'Tidak ada data.';
$lang['kat_must_fill'] = 'Kategori harus diisi!';
$lang['subkat_must_fill'] = 'Kategori dan Subkategori harus diisi!';
$lang['form_complete'] = 'Lengkapi form tersebut!';

$lang['list_subkat'] = 'Daftar Subkategori';
$lang['produk'] = 'Produk';

$lang['list_subkat2'] = 'Daftar Subkategori Level 2';
$lang['subkat2'] = 'Subkategori2';
$lang['input_subkat2'] = 'Input Subkategori Level 2';
$lang['det_subkat2'] = 'Detail Subkategori Level 2';
$lang['edit_subkat2'] = 'Edit Subkategori Level 2';
