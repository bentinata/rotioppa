<?php
$lang['list_fu'] = 'List FollowUp Email';
$lang['subject_mail'] = 'Email Subjek';
$lang['type_mail'] = 'Tipe Email';
$lang['status_mail'] = 'Status Email';
$lang['test_mail'] = 'Tes Email';
$lang['status_mail_array'] = array('1'=>'enable','0'=>'disable');
$lang['type_mail_array'] = array('1'=>'text','2'=>'html');
$lang['make_fu'] = 'Buat Email Baru';

$lang['edit_fu'] = 'Edit Email';
$lang['detail_fu'] = 'Detail Email';
$lang['subject'] = 'Subjek';
$lang['email'] = 'Email';
$lang['email_for'] = 'Email Untuk';

$lang['update_ok'] = 'Update Email Berhasil.';
$lang['update_error'] = 'Update Email Gagal.';
$lang['input_ok'] = 'Input Email Berhasil.';
$lang['input_error'] = 'Input Email Gagal.';

$lang['sure_dell_mail'] = 'Yakin akan dihapus?';
$lang['sure_to_change_formail'] = 'Yakin akan diganti? \r\nKarena isi email dan subjek akan dikosongkan kembali.';