<?php
$lang['list_kupon'] = 'List Kupon';
$lang['kode_kupon'] = 'Kode Kupon';
$lang['jenis_kupon'] = 'Jenis Kupon';
$lang['nilai_kupon'] = 'Nilai Kupon';
$lang['tgl_awal'] = 'Tgl. Awal';
$lang['tgl_akhir'] = 'Tgl. Akhir';
$lang['status_kupon'] = 'Status Kupon';

$lang['jenis_kupon_array'] = array('1'=>'Rupiah','2'=>'Persentase');
$lang['status_kupon_array'] = array('1'=>'Enable','2'=>'Disable');
$lang['sure_dell_kupon'] = 'Yakin kupon akan dihapus?';
$lang['no_data'] = 'Tidak ada data kupon';

$lang['input_kupon'] = 'Input Kupon';
$lang['edit_kupon'] = 'Edit Kupon';
$lang['det_kupon'] = 'Detail Kupon';

$lang['update_ok'] = 'Update Kupon Berhasil.';
$lang['update_error'] = 'Update Kupon Gagal.';
$lang['input_ok'] = 'Input Kupon Berhasil.';
$lang['input_error'] = 'Input Kupon Gagal.';
$lang['add_kupon'] = 'Input kode kupon';
