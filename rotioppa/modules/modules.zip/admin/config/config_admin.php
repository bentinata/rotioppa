<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['modulename'] = 'admin';

$config['bcast_to'] = array(
	'1'=>'member',
	'2'=>'prospek',
	'3'=>'affiliate'
);


