
<div id="block-sidebar_kanan" class="width-sidebar">
				<div class="box_testi">
				
					<div class="testimoni" align="left">
						KATEGORI PRODUK<div class="garis2"></div>
					</div>
					<div class="testi-isi">
						<ul>
							<? if(isset($list_kat_sub) && $list_kat_sub){
							foreach($list_kat_sub as $idkat=>$kat){?>
							<li><a href="<?=site_url('home/listproduk/index/'.$idkat) ?>"><?= $kat['sub'] ?></a></li>
							<? }} ?>
						</ul>
					</div>
				</div>
			</div>