<div id="jb-collection">
	<div class="wrap_judul">
		<div class="wrap_slide">
			<div class="container">
				<div class="judul">
						Produk Terbaru
					</div>
					<div class="garis"></div>
				<div id="ca-container" class="ca-container">
					
					<div class="ca-wrapper">
					<? if($new){foreach($new as $pr){					
					$gbr=unserialize($pr->gbr); 
					$ha=get_price($pr->ha_prop,$pr->hb_prop,$pr->ha_diskon,$pr->hb_diskon,'ha');
					$hb=get_price($pr->ha_prop,$pr->hb_prop,$pr->ha_diskon,$pr->hb_diskon);	?>
					
						<div class="ca-item ca-item-1">
							<div class="ca-item-main">
								<a href="<?=site_url('home/detail/index/'.$pr->id.'/'.en_url_save($pr->nama_produk))?>" align="center"><?=loadImgProduk($pr->id.'/'.$pr->idgbr.'/'.$gbr['intro'])?></a>
								<a href="<?=site_url('home/detail/index/'.$pr->id.'/'.en_url_save($pr->nama_produk))?>"><h3><?=$pr->nama_produk ?></h3></a>
								<? if($hb==0){?>
								<span class="rp-now">Rp. <?=currency($ha)?></span>
								<? }else{?>
								<span class="rp">Rp. <?=currency($ha)?></span>
								<span class="rp-now"> Rp. <?=currency($hb)?></span>
								<? }?>
								<div class="beli">
									<span><a href="<?=site_url('home/detail/index/'.$pr->id.'/'.en_url_save($pr->nama_produk))?>"><?=theme_img('beli_sekarang.png')?></a></span>
									<span><a href="<?=site_url('home/detail/index/'.$pr->id.'/'.en_url_save($pr->nama_produk))?>"><?=theme_img('details.png')?></a></span>
								</div>
							</div>
						</div>	
					<? }}?>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
		<!-- the jScrollPane script -->
		<script type="text/javascript" src="js/jquery.mousewheel.js"></script>
		<script type="text/javascript" src="js/jquery.contentcarousel.js"></script>
		<?=loadJs('jquery.mousewheel.js',false,true)?>
		<?=loadJs('jquery.contentcarousel.js',false,true)?>
		<?=loadJs('jquery.easing.1.3.js',false,true)?>
		<script type="text/javascript">
			$('#ca-container').contentcarousel();
		</script>

<style>
.a{color:#eaf2f9;}
</style>