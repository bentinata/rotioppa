<div id="intro" class="katalog_m">
	<ul>
		<a href="<?=site_url('home/listproduk/katalog/1')?>">
			<li class="katalog">
				<div class="kiri">
					<?=theme_img('kat_1.png')?>		
				</div>
				<div class="kanan">
					<div class="warna wrn1">
						<h1>My Happy Family</h1>
						<p>Koleksi Pakaian Anak Untuk Keluarga</p>
					</div>
				</div>
			</li>
		</a>
		<a href="<?=site_url('home/listproduk/katalog/1')?>">
			<li class="katalog">
				<div class="kiri">
					<?=theme_img('kat_2.png')?>		
				</div>
				<div class="kanan">
					<div class="warna wrn2">
						<h1>Aku Anak Muslim</h1>
						<p>Koleksi Pakaian Anak Muslim Formal</p>
					</div>
				</div>
			</li>
		</a>
		</ul>
		<ul>
		<a href="<?=site_url('home/listproduk/katalog/2')?>">
			<li class="katalog">
				<div class="kiri">
					<?=theme_img('kat_3.png')?>		
				</div>
				<div class="kanan">
					<div class="warna wrn3">
						<h1>My Funny Day</h1>
						<p>Koleksi Pakaian Anak Untuk Sehari - hari</p>
					</div>
				</div>
			</li>
		</a>
		<a href="<?=site_url('home/listproduk/katalog/1')?>">
			<li class="katalog">
				<div class="kiri">
					<?=theme_img('kat_4.png')?>		
				</div>
				<div class="kanan">
					<div class="warna wrn4">
						<h1>My Special Day</h1>
						<p>Koleksi Pakaian Anak Untuk Bermain</p>
					</div>
				</div>
			</li>
		</a>
	</ul>
</div>