<ul class="footer">
<li class="block1" style="background:none;padding:0;">
	<p class="copy" style="margin:0">Copyright &copy; 2014 Zena Teqlla</p>
	Muslim | Muslimah | Hijab | Gaya terbaru muslimah
</li>
<li class="block2">
</li>
<li class="block3">
</li>
<li class="block3">
</li>
<li class="block4">
	<?=theme_img('sosmed-fb.jpg')?>
	<?=theme_img('sosmed-pat.jpg')?>
	<?=theme_img('sosmed-tweet.jpg')?>
	<?=theme_img('sosmed-instagram.jpg')?>
</li>
</ul>
