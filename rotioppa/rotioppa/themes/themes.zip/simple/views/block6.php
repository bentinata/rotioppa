<div class="intro2">		
	<ul>
		<li id="block-sidebar_fb" class="leftside width-sidebar">
			<div id="block-sidebar_fb" class="leftside width-sidebar">
				<div class="box_fb">
						<div id="fb-root"></div>
						<!--<script>
							(function(d, s, id) {
							  var js, fjs = d.getElementsByTagName(s)[0];
							  if (d.getElementById(id)) return;
							  js = d.createElement(s); js.id = id;
							  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&appId=173374306162681&version=v2.0";
							  fjs.parentNode.insertBefore(js, fjs);
							}(document, 'script', 'facebook-jssdk'));
						</script>-->
					<div class="keterangan_fb">
						<!--<div class="fb-like-box" data-href="https://www.facebook.com/FacebookDevelopers" data-width="560" data-height="300" data-colorscheme="light" data-show-faces="false" data-header="false" data-stream="true" data-show-border="false"></div>-->
					</div>
				</div>
			</div>
		</li>
		<li id="block-sidebar_tweet" class="leftside width-sidebar">
			<div id="block-sidebar_tweet" class="leftside width-sidebar">
				<div class="box_tweet">
					<div class="keterangan_tweet">
						<!--<a class="twitter-timeline" height="300" href="https://twitter.com/srifitriah" data-widget-id="549747078985809920">Tweet oleh @srifitriah</a>
						<script>
							!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
						</script>-->
					</div>
				</div>
			</div>
		</li>
	</ul>
</div>