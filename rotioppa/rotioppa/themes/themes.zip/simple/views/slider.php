<!-- image slider -- >
<? #=loadJs('nivoslider/jquery.nivo.slider.pack.js')?>
<? #=loadCss('js/nivoslider/nivo-slider.css',false,false,false,true)?>
<script type="text/javascript">
$(document).ready(function(){	
	$("#slider").nivoSlider({
		effect:'fold',
		captionOpacity:0,
		animSpeed:100,
		pauseTime:8000
	});

	$("a.showBigC").fancybox({
		'padding'			:5,
		'titleShow'    	:false,
		'transitionIn'		:'elastic',
		'transitionOut'	:'elastic',
		'speedIn'			:500,
		'centerOnScroll'	:true,
		'onComplete': function(){$("#fancybox-outer").css("background","transparent");}
	});

});	
</script -->
<div id="slider" class="big-banner">
	<div  id="wowslider-container1">
		<div class="ws_images"><ul>
			<!--li><img src="<?=theme_img('banner.png',false)?>" alt="banner1" title="banner1" id="wows1_0" style="width:1152px;"/>
			<div class="footer-banner">Product Will available  on 31 August  <a href="">More &raquo;</a></div>
			</li-->
			<li><img src="<?=theme_img('banner.png',false)?>" alt="banner1" title="banner1" id="wows1_0"/></li>
			<li><img src="<?=theme_img('banner.png',false)?>" alt="banner2" title="banner3" id="wows1_0"/></li>
			<li><img src="<?=theme_img('banner.png',false)?>" alt="banner3" title="banner3" id="wows1_0"/></li>
		</ul></div>
		<div class="ws_bullets"><div><a href="#" title="1">1</a><a href="#" title="2">2</a><a href="#" title="3">3</a></div></div>
    </div>
</div>



<?=loadCss('js/wowslider/style.css',false,false,false,true)?>
<?=loadJs('wowslider/wowslider.js')?>
<?=loadJs('wowslider/effect/stack/script.js')?>