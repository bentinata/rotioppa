<div class="garis_atas"></div>
<ul class="footer">
	<li class="block1">
		<h3>Follow Us</h3>
		<a href="https://www.facebook.com/naylakidz.shop" target="_blank"><?=theme_img('sosmed-fb.png')?></a>
		<a href="https://twitter.com/naylakidz" target="_blank"><?=theme_img('sosmed-tweet.png')?></a>
		<a href="https://www.youtube.com/user/naylakidz/videos" target="_blank"><?=theme_img('sosmed-youtube.png')?></a>
	</li>
	<li class="block2">
		<h3>About</h3>
		<p>
				Konfirmasi Pembayaran
			<br>
				<a href="<?=site_url('home/sistem_pengiriman')?>">Sistem Pengiriman</a>
			<br>
				<a href="<?=site_url('home/calculatorshipping')?>">Calculator Shipping</a>
			<br>
				FAQ
			<br>
				<a href="<?=site_url('aff')?>">Affiliate</a>
		</p>
	</li>
	<li class="block3">
		<h3>Address</h3>
		<p>Naylakidz Office, Jl Pratista Timur 1<br>No.8, Bandung</p>
	</li>
	<li class="block4">
		<h3>Contact</h3>
		<p><label>Call Center</label>: 081320572408</p>
		<p><label>SMS/WA</label>: 089315246888
		<p><label>BB</label>: 7F2BB16B
		<p><label>Info Keagenan</label>: 275AE517, 280E3D12
	</li>
	</ul>
    <div style="border-bottom:1px solid #fb9b11;"></div>
<div class="copyright">
	<div class="copyright-l">2012-2015 Naylakidz  | Powered by CyberLabs</div>
    <div class="copyright-r"><span id="to-top" style="cursor:pointer">Back To Top &#8593 </span></div>
<div class="clear"></div>
</div>