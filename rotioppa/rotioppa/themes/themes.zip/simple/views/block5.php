<div class="wrap_block5">
<div id="intro2">
<br>
	<div class="wrap_ket">
		<div class="keterangan_video" style="margin-right:5%;">
			<div class="wrap-ct">
				<div class="head-title-member">
					<center><h3>Facebook</h3></center>
				</div>
				<br>
                
 				<div class="block5-isi">
                </div>
				<br>
			</div>
		</div>
		<div class="keterangan_video" style="margin-right:5%;">
			<div class="wrap-ct">
				<div class="head-title-member">
					<center><h3>Twitter</h3></center>
				</div>
				<br />
                
 				<div class="block5-isi">
                </div>
				<br />
			</div>
		</div>
		<div class="keterangan_video">
			<div class="wrap-ct">
				<div class="head-title-member">
					<center><h3>Testimoni</h3></center>
				</div>
				<br />
 				<div class="block5-isi">
                    <ul>
                    <? if($testimoni){foreach($testimoni as $ts){ ?>
                        <li>
                            <div class='wrap_testi'>
                                <div class='box_news'>
                                    <div class='isi'>
                                        <div class='wrap_author'>
                                            <div class='isi_testi'><i><?=$ts->testimoni?></i></div>
                                            <div class='author_testi'><?=$ts->pengirim ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <? } } ?>
                        <li>
                        	<a class="btn" href="<?=site_url('home/view_testimoni')?>">SHOW MORE</a>
                        </li>
                     </ul>
                </div>
			</div>
		</div>
	</div>
	<!--<ul>
		<li id="block-sidebar_video" class="leftside width-sidebar">
			<div id="block-sidebar_video" class="leftside width-sidebar">
				<div class="box_video">
					<div class="b_box_video">
						
					</div>
				</div>
			</div>
		</li>
	</ul>-->
</div>
</div>