	
	<ul id="block4">
		<li id="block-sidebar_kiri">
		<div class="judul_on">
				Naylakidz On Media
			</div>
            <br />
			<div class="leftside width-sidebar" style="width:100%">
					<div class="boxrounded_fb">
						<iframe width="100%" height="224" src="//www.youtube.com/embed/j4zTrPJG4u4" frameborder="0" allowfullscreen></iframe>
					</div>
			</div>
			
			<div class="leftside width-sidebar" style="width:100%;">
				
				<div class="boxrounded_tweet">
					<div class="ket_video" style="float:none;">
						<p>Beberapa waktu lalu Naylakidz kedatangan tamu istimewa dari Media. Ya mereka adalah teman-teman dari IMTV yang datang untuk meliput kegiatan Naylakidz mulai dari produksi sampai penjualan. Beberapa waktu lalu Naylakidz kedatangan tamu istimewa dari Media. Ya mereka adalah teman-teman dari IMTV yang datang untuk meliput kegiatan Naylakidz mulai dari produksi sampai penjualan. Beberapa waktu lalu Naylakidz kedatangan tamu istimewa dari Media. Ya mereka adalah teman-teman dari IMTV yang datang untuk meliput kegiatan Naylakidz mulai dari produksi sampai penjualan. </p>
					</div>
				</div>
			</div>
		</li>
		
		<li id="block-sidebar_tengah" class="width-sidebar">
			<div class="judul_new_post">
					News Post &nbsp &nbsp &nbsp
				</div>
            <br />
			<div class="width-sidebar">
				<div class="latest_news" style="overflow-y:scroll">
						<div class="box_news">
                        <style>
							.latest_news .box_news .isi img{width:90%; height:auto}
						</style>
						<? if($artikel){foreach($artikel as $ar){?>
							<div class="isi">
                            	<? $a = "home/berita/".$ar->id;?>
								<div class="judul_news"><a href="<?=site_url($a)?>"><?=$ar->title?></a></div>
								<p><span><?=$ar->date_input?></span><br><?=$ar->summary?></p> 
							</div>
							<div class="garis_news"></div>
						<? }}?>
					</div>
				</div>
			</div>
		</li>
		<li id="block-sidebar_kanan" class="width-sidebar newsletter">
			<div class="judul_on">
				News Letter
			</div>
            <br />
			<?=$template['partials']['pg_sidebar'];?>
		</li>
	</ul>