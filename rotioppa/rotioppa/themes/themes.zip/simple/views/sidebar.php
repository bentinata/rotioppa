			<div class="rightside width-sidebar">
				<div class="b_box">
					<div class="box">
						<div class="ampp">
							<img src="<?=theme_img('ampp.png',false)?>">
						</div>
						<div align="center" class="amp">
							<img src="<?=theme_img('amp.png',false)?>">
							<br><p class="putih">Dapatkan info</p><b>DISCOUNT & PROMO</b><br><p class="putih">dengan mengisi form di bawah ini</p><br><br>
						</div>
						
						<div class="form-input">
							<?=form_open('home/reg',array('id'=>'iform'))?>
								<input class="tinput" type="text" name="inama" placeholder="<?=lang('inama')?>" /><input class="tinput" type="text" name="imail" placeholder="<?=lang('imail')?>" /><?=lang('icode')?>
								<input class="isubmit" type="submit" name="_ISUBMIT" value="<?=lang('subscribe')?>" />
								<?=form_close()?>
						</div>
					</div>
				</div>
			</div>
<style>		
.putih{color:#fff;}
</style>		