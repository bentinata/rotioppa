
<div id="block-sidebar_kanan" class="width-sidebar">
				<div class="box_testi">
					<div class="testimoni" align="left">
						ARTIKEL LAINNYA<div class="garis2"></div>
					</div>
					<div class="testi-isi">
						<ul>
							<? if($berita){foreach($berita as $br){?>
							<li><a href="<?=site_url("home/berita/".$br->id)?>"><?= $br->title; ?></a></li>
							<? }}?>
						</ul>
					</div>
				</div>
			</div>