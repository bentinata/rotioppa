<br>
<div class="jb-topbar">
<a href="<?=site_url('home/index')?>"></a>
	<div id="block-wrap">
    	<div class="jb-topbar-left">
        	<img src="<?=theme_img('logo.png',false)?>" />
        </div>
        
        <div class="jb-topbar-right">
            <div class="log">
            <? if($this->login_lib->m_has_login()){?>
                <a href="<?=site_url('login/logout')?>" class="login">Log Out</a>
                <a href="<?=site_url('member')?>" class="daftar">Member</a>
            <? }else{?>
                <a href="<?=site_url('login') ?>" class="login">Masuk</a> 
                <a href="<?=site_url('home/reg') ?>" class="daftar">Daftar</a>
            <? }?>
            </div>
            
            <form method="post" action="<?=site_url('home/search')?>" class="cart-search">
                <ul>
                    <li><input type="text" name="search" required="required" placeholder="Cari" /><span class="search">&nbsp;</span></li>
                    <li><img src="<?=theme_img('cartw.png',false)?>" class="cart-top" width="20" height="20" align="left"><a href="<?=site_url('home/cart')?>"><?=$count_cart?> Item(s)</a></li>
                </ul>
            </form>
            
            <div class="ongkir">
                Free Ongkir ke Seluruh Indonesia Untuk Pembelian Paket Sampel
            </div>
        </div>
	</div>
</div>

	<nav id='cssmenu'>
    
		<div id="head-mobile">
        	<div class="nav-login" style="margin:-11px 35px 0px 0; height:30px; float:left;">
            	<a href="<?=site_url('home/cart')?>" style="margin-right:20px" class="cart-button"><img src="<?=theme_img('cart24.png',false)?>" /></a>
                <img style="margin-right:20px" class="search-button" src="<?=theme_img('search24.png',false)?>"  />
                <img style="margin-right:20px" class="user-button" src="<?=theme_img('user24.png',false)?>" />
            </div>
        </div>
        
        <div class="nav-search" style="width:100%;height:40px; border-top:solid #e81b3d 1px">
        		<div id='search-box'>
                    <form action="<?=site_url('home/search')?>" id="search-form" method="post">
                        <input id="search-text" name="search" required="required" placeholder="Masukan Nama Barang" type="text"/>
                        <button id='search-button' type='submit'><span>Cari</span></button>
                    </form>
                </div>
        </div>
        <div class="nav-user" style="width:100%;height:40px; border-top:solid #e81b3d 1px">
        		<div id='user-box'>
                    <? if($this->login_lib->m_has_login()){?>
                        <a href="<?=site_url('login/logout')?>" class="mlogin">Log Out</a>
                        <a href="<?=site_url('member')?>" class="mdaftar">Member</a>
                    <? }else{?>
                        <a href="<?=site_url('login') ?>" class="mlogin">Masuk</a> 
                        <a href="<?=site_url('home/reg') ?>" class="mdaftar">Daftar</a>
                    <? }?>
                </div>
        </div>
        
        
		<div class="mbutton"></div>
		<ul>
        	<li><a href='<?=site_url('home/home')?>'> Beranda</a></li>
			<li><a href='<?=site_url('home/our_history')?>'>Tentang naylakidz</a></li>
			<li><a href='<?=site_url('home/our_history')?>'>Katalog naylakidz</a>
				<ul>
					<? if(isset($list_katalog) && $list_katalog){
					foreach($list_katalog as $idkat=>$kat){?>
					<li><a href="<?=site_url('home/listproduk/katalog/'.$idkat) ?>"><?= $kat['kat'] ?></a></li>
					<? }} ?>
				</ul>
			</li>
			<li><a href="<?=site_url('home/listproduk')?>">Kategori Produk</a>
				<ul>
					<? if(isset($list_kat_sub) && $list_kat_sub){
					foreach($list_kat_sub as $idkat=>$kat){?>
					<li><a href="<?=site_url('home/listproduk/index/'.$idkat) ?>"><?= $kat['sub'] ?></a></li>
					<? }} ?>
				</ul>
			</li>
			<li><a href='#'>Mitra</a>
				<ul>
					
					<li><a href='#'>Paket Kemitraan</a>
						<ul>
							<li><a href="">Paket Sample Naylakidz</a></li>
							<li><a href="">Paket Agen Naylakidz</a></li>
							<li><a href="">Paket Distributor</a></li>
							<li><a href="">Paket Distributor Ekslusif</a></li>
						</ul>
					</li>
					<li><a href="<?=site_url('home/point_reward')?>">Point Reward</a></li>
					<li><a href="<?=site_url('home/daftar_mitra')?>">Daftar Mitra Naylakidz</a></li>
					<li><a href="<?=site_url('home/pendaftaran_mitra')?>">Pendaftaran Mitra Naylakidz</a></li>
					<!--<li><a href="<?=site_url('home/cek_stock')?>">Cek Stock</a></li>-->
					<li><a href="<?=site_url('home/download_katalog')?>">Download Katalog</a></li>			
				</ul>
			</li>
			<li><a href="<?=site_url('home/view_testimoni')?>">Testimoni</a></li>
			<li><a href="<?=site_url('home/listproduk/index/promo')?>">Produk Promo</a></li>
			<li><a href="<?=site_url('home/berita_terbaru')?>">Artikel</a></li>
		</ul>
	</nav>
    
    
    