<div id="myslidemenu" class="jqueryslidemenu">
<ul>
<li><?=anchor(config_item('modulename'),loadImgThem('icon/home.png','',false,config_item('modulename'),true).'Home')?></li>
<li><?=anchor(config_item('modulename').'/member',loadImgThem('icon/member.png','',false,config_item('modulename'),true).'Member')?></li>
<li><?=anchor(config_item('modulename').'/prospek',loadImgThem('icon/member.png','',false,config_item('modulename'),true).'Prospek')?></li>
<li><?=anchor(config_item('modulename').'/transaksi',loadImgThem('icon/transaksi.png','',false,config_item('modulename'),true).'Transaksi')?></li>
<li><?=anchor(config_item('modulename').'/aff',loadImgThem('icon/money.png','',false,config_item('modulename'),true).'Affiliate')?>
	<? /*<ul>
	<li><?=anchor(config_item('modulename').'/aff',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List Affiliate')?></li>
	<li><?=anchor(config_item('modulename').'/komisi',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Komisi')?></li>
	</ul>*/?>
</li>
<li><?=anchor(current_url().'#',loadImgThem('icon/seting.png','',false,config_item('modulename'),true).'Pengaturan')?>
	<ul>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Kategori')?>
		<ul>
			<li><?=anchor(config_item('modulename').'/kategori',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/kategori/input',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Kategori')?></li>
		</ul>
		</li>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Subkategori')?>
		<ul>
			<li><?=anchor(config_item('modulename').'/kategori/sub',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/kategori/subinput',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Subkategori')?></li>
		</ul>
		</li>
		<? /*<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Subkategori2')?>
		<ul>
			<li><?=anchor(config_item('modulename').'/kategori/sub2',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/kategori/subinput2',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Subkategori2')?></li>
		</ul>
		</li>*/?>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Katalog')?>
			<ul>
				<li><?=anchor(config_item('modulename').'/katalog',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
				<li><?=anchor(config_item('modulename').'/kategori/input',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Katalog')?></li>
			</ul>
		</li>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Vendor')?>
		<ul>
			<? /*<li><?=anchor(config_item('modulename').'/vendor',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/vendor/input',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Vendor')?></li>*/?>
			<li><?=anchor(config_item('modulename').'/vendor/vcode',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List Kode Vendor')?></li>
			<li><?=anchor(config_item('modulename').'/vendor/vcodeinput',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Kode Vendor')?></li>
		</ul>
		</li>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Produk')?>
		<ul>
			<li><?=anchor(config_item('modulename').'/produk',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/produk/listvendor',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List Berds.Vendor')?></li>
			<li><?=anchor(config_item('modulename').'/produk/input',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Produk')?></li>
		</ul>
		</li>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Biaya Kirim')?>
		<ul>
			<li><?=anchor(config_item('modulename').'/biayakirim',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/biayakirim/input',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Biaya')?></li>
			<li><?=anchor(config_item('modulename').'/biayakirim/listprov',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List Provinsi')?></li>
			<li><?=anchor(config_item('modulename').'/biayakirim/inputprov',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Provinsi')?></li>
			<li><?=anchor(config_item('modulename').'/biayakirim/listkota',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List Kota')?></li>
			<li><?=anchor(config_item('modulename').'/biayakirim/inputkota',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input Kota')?></li>
			<li><?=anchor(config_item('modulename').'/biayakirim/pengiriman',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Layanan Pengiriman')?></li>
		</ul>
		</li>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Info Member')?>
		<ul>
			<li><?=anchor(config_item('modulename').'/info',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/info/input',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input')?></li>
		</ul>
		</li>
		<li><?=anchor(current_url().'#',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'FAQ')?>
		<ul>
			<li><?=anchor(config_item('modulename').'/info/faq',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'List')?></li>
			<li><?=anchor(config_item('modulename').'/info/inputfaq',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Input')?></li>
		</ul>
		</li>
		<? /*<li><?=anchor(config_item('modulename').'/kupon',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Kupon')?>*/?>
		<li><?=anchor(config_item('modulename').'/update_pass',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Edit Password')?>
	</ul>
</li>
<li><?=anchor(current_url().'#',loadImgThem('icon/email_go.png','',false,config_item('modulename'),true).'Email')?>
	<ul>
	<li><?=anchor(config_item('modulename').'/broadcast',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Broadcast')?></li>
	<li><?=anchor(config_item('modulename').'/folowup',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Email Folowup')?></li>
	</ul>
</li>
<li><?=anchor(config_item('modulename').'/wishlist',loadImgThem('icon/basket.png','',false,config_item('modulename'),true).'Wishlist')?></li>
<li><?=anchor(config_item('modulename').'/excel',loadImgThem('icon/excel.png','',false,config_item('modulename'),true).'Download')?></li>
<li><?=anchor(current_url().'#',loadImgThem('icon/edit.png','',false,config_item('modulename'),true).'Page')?>
	<ul>
	<li><?=anchor(config_item('modulename').'/create_page',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'About Us')?></li>
	<li><?=anchor(config_item('modulename').'/create_page/mitra',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Kemitraan')?></li>
	<li><?=anchor(config_item('modulename').'/create_page/contact',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Contact Us')?></li>
	<li><?=anchor(config_item('modulename').'/artikel',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Artikel')?></li>
	<li><?=anchor(config_item('modulename').'/testimoni',loadImgThem('icon/bullet_green.png','',false,config_item('modulename'),true).'Testimoni')?></li>
    </ul>
</li>
<li><?=anchor('login/'.config_item('modulename').'/logout',loadImgThem('icon/disconnect.png','',false,config_item('modulename'),true).'Logout')?></li>
</ul>
<br style="clear: left" />
</div>
